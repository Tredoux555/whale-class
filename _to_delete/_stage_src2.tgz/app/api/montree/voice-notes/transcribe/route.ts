// app/api/montree/voice-notes/transcribe/route.ts
// Transcribe audio blob via OpenAI Whisper — returns text + detected language

import { NextRequest, NextResponse } from 'next/server';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { checkRateLimit } from '@/lib/rate-limiter';
import { getSupabase } from '@/lib/supabase-client';

// Railway/Next.js default serverless timeout is 15s. Whisper transcription on
// a 60-90s recording can easily exceed that — without this export, the route
// gets killed mid-flight and returns 503 (Service Unavailable). 90s gives
// Whisper headroom for accent handling, multi-language detection, and the
// occasional cold-start penalty.
export const maxDuration = 90;

export async function POST(request: NextRequest) {
  // Auth
  const auth = await verifySchoolRequest(request);
  if (auth instanceof NextResponse) return auth;

  // Rate limit: 30 per minute per teacher
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const supabase = getSupabase();
  const { allowed } = await checkRateLimit(supabase, ip, '/api/montree/voice-notes/transcribe', 30, 1);
  if (!allowed) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 });
  }

  try {
    const formData = await request.formData();
    const audioFile = formData.get('audio') as Blob | null;

    if (!audioFile || audioFile.size < 100) {
      return NextResponse.json({ error: 'Audio file required (min 100 bytes)' }, { status: 400 });
    }

    // Max 5MB for a quick voice note
    if (audioFile.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: 'Audio too large (max 5MB)' }, { status: 400 });
    }

    if (!process.env.OPENAI_API_KEY) {
      console.error('[voice-notes] OPENAI_API_KEY not configured');
      return NextResponse.json(
        { error: 'Transcription service not configured', code: 'MISSING_API_KEY' },
        { status: 503 }
      );
    }

    // Prepare form data for Whisper API
    const whisperForm = new FormData();
    const buffer = await audioFile.arrayBuffer();
    const blob = new Blob([buffer], { type: audioFile.type || 'audio/webm' });
    whisperForm.append('file', blob, 'recording.webm');
    whisperForm.append('model', 'whisper-1');
    whisperForm.append('response_format', 'verbose_json');
    // Don't set language — let Whisper auto-detect (supports en + zh)

    // Add timeout (30s) for Whisper API call
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    try {
      const whisperResponse = await fetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: whisperForm,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!whisperResponse.ok) {
        const errorText = await whisperResponse.text().catch(() => 'Unknown error');
        console.error('[voice-notes] Whisper API error:', whisperResponse.status, errorText);
        return NextResponse.json(
          { error: 'Transcription failed', code: 'WHISPER_API_ERROR' },
          { status: 502 }
        );
      }

      const result = await whisperResponse.json();

      // Calculate duration from Whisper response
      const duration = result.duration ? Math.ceil(result.duration) : 0;

      return NextResponse.json({
        success: true,
        transcript: result.text?.trim() || '',
        language: result.language || 'en',
        duration_seconds: duration,
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err instanceof Error && err.name === 'AbortError') {
        console.error('[voice-notes] Whisper API timeout');
        return NextResponse.json(
          { error: 'Transcription took too long', code: 'TIMEOUT' },
          { status: 504 }
        );
      }
      console.error('[voice-notes] Whisper API error:', err);
      return NextResponse.json(
        { error: 'Transcription failed', code: 'API_ERROR' },
        { status: 502 }
      );
    }
  } catch (err) {
    console.error('[voice-notes] Transcribe error:', err);
    return NextResponse.json(
      { error: 'Transcription failed', code: 'UNKNOWN_ERROR' },
      { status: 500 }
    );
  }
}
