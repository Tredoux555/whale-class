// /api/montree/progress/summary/route.ts
// Returns progress summary per area for bar chart display

import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase-client';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { verifyChildBelongsToSchool } from '@/lib/montree/verify-child-access';

const AREA_KEYS = ['practical_life', 'sensorial', 'mathematics', 'language', 'cultural'];

export async function GET(request: NextRequest) {
  try {
    const auth = await verifySchoolRequest(request);
    if (auth instanceof NextResponse) return auth;

    const supabase = getSupabase();
    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('child_id');

    if (!childId) {
      return NextResponse.json({ error: 'child_id required' }, { status: 400 });
    }

    const access = await verifyChildBelongsToSchool(childId, auth.schoolId);
    if (!access.allowed) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // First get the child's classroom_id
    const { data: childData } = await supabase
      .from('montree_children')
      .select('classroom_id')
      .eq('id', childId)
      .maybeSingle();

    const classroomId = childData?.classroom_id;
    if (!classroomId) {
      return NextResponse.json({ error: 'Child not in a classroom' }, { status: 400 });
    }

    // Parallelize: fetch works AND progress simultaneously (they're independent)
    const [worksResult, progressResult] = await Promise.all([
      supabase
        .from('montree_classroom_curriculum_works')
        .select(`
          id, name, sequence,
          area:montree_classroom_curriculum_areas!area_id (
            area_key
          )
        `)
        .eq('classroom_id', classroomId)
        .eq('is_active', true)
        .order('sequence'),
      // Single query with ALL columns needed (eliminates double-fetch)
      supabase
        .from('montree_child_progress')
        .select('id, work_name, status, area, presented_at, mastered_at, updated_at')
        .eq('child_id', childId)
        .order('updated_at', { ascending: false }),
    ]);

    const { data: allWorks, error: worksError } = worksResult;
    const { data: progress, error: progressError } = progressResult;

    if (worksError) {
      console.error('Works fetch error:', worksError);
      return NextResponse.json({ error: 'Failed to fetch curriculum' }, { status: 500 });
    }

    if (progressError) {
      console.error('Progress fetch error:', progressError);
      return NextResponse.json({ error: 'Failed to fetch progress' }, { status: 500 });
    }

    // Create progress lookup by work_name (normalized to lowercase)
    const progressMap = new Map();
    for (const p of progress || []) {
      progressMap.set(p.work_name?.toLowerCase(), p.status);
    }

    // Calculate per-area stats
    const areaSummary = AREA_KEYS.map(areaKey => {
      const areaWorks = (allWorks || []).filter(w => w.area?.area_key === areaKey);
      const totalWorks = areaWorks.length;
      
      let completed = 0;
      let inProgress = 0;
      let currentWork = null;
      let currentWorkIndex = 0;

      for (let i = 0; i < areaWorks.length; i++) {
        const work = areaWorks[i];
        const status = progressMap.get(work.name?.toLowerCase());
        
        if (status === 3 || status === 'mastered' || status === 'completed') {
          completed++;
        } else if (status === 1 || status === 2 || status === 'presented' || status === 'practicing') {
          inProgress++;
          if (!currentWork || (work.sequence || 0) > (currentWork.sequence || 0)) {
            currentWork = work;
            currentWorkIndex = i;
          }
        }
      }

      // If no work in progress, current = first non-completed work
      if (!currentWork && areaWorks.length > 0) {
        for (let i = 0; i < areaWorks.length; i++) {
          const work = areaWorks[i];
          const status = progressMap.get(work.name?.toLowerCase());
          if (status !== 3 && status !== 'mastered' && status !== 'completed') {
            currentWork = work;
            currentWorkIndex = i;
            break;
          }
        }
      }

      const progressPercent = totalWorks > 0 
        ? Math.round((completed / totalWorks) * 100) 
        : 0;

      return {
        area: areaKey,
        totalWorks,
        completed,
        inProgress,
        progressPercent,
        currentWork: currentWork ? {
          id: currentWork.id,
          name: currentWork.name,
          index: currentWorkIndex + 1,
        } : null,
      };
    });

    const totalCompleted = areaSummary.reduce((sum, a) => sum + a.completed, 0);
    const totalWorks = areaSummary.reduce((sum, a) => sum + a.totalWorks, 0);
    const overallPercent = totalWorks > 0 ? Math.round((totalCompleted / totalWorks) * 100) : 0;

    // Reuse the already-fetched progress data (already sorted by updated_at desc)
    const response = NextResponse.json({
      success: true,
      areas: areaSummary,
      overall: {
        completed: totalCompleted,
        total: totalWorks,
        percent: overallPercent,
      },
      progress: progress || [],
    });
    response.headers.set('Cache-Control', 'private, max-age=60, stale-while-revalidate=120');
    return response;

  } catch (error) {
    console.error('Summary API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
