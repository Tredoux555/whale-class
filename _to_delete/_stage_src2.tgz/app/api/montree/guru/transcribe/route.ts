// app/api/montree/guru/transcribe/route.ts
// Voice Notes — Transcribe audio via OpenAI Whisper
// Audio is NOT stored — transcribe and discard (privacy + storage)

import { NextRequest, NextResponse } from 'next/server';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { checkRateLimit } from '@/lib/rate-limiter';
import { getSupabase } from '@/lib/supabase-client';


// Railway/Next.js default serverless timeout is 15s. AI calls can
// exceed that and return 503 (Service Unavailable). 90s gives the
// route enough headroom while still bounded.
export const maxDuration = 90;

export async function POST(request: NextRequest) {
  try {
    const auth = await verifySchoolRequest(request);
    if (auth instanceof NextResponse) return auth;

    // Rate limit (Whisper bills per audio-minute) — 30/min per teacher,
    // matching /api/montree/voice-notes/transcribe.
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const { allowed } = await checkRateLimit(getSupabase(), ip, '/api/montree/guru/transcribe', 30, 1);
    if (!allowed) {
      return NextResponse.json({ success: false, error: 'Rate limit exceeded' }, { status: 429 });
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    if (!OPENAI_API_KEY) {
      return NextResponse.json(
        { success: false, error: 'Voice transcription is not configured' },
        { status: 503 }
      );
    }

    // Get audio from FormData
    const formData = await request.formData();
    const audioFile = formData.get('audio') as File | null;

    if (!audioFile) {
      return NextResponse.json(
        { success: false, error: 'No audio file provided' },
        { status: 400 }
      );
    }

    // Validate file size (max 25MB — Whisper's limit)
    if (audioFile.size > 25 * 1024 * 1024) {
      return NextResponse.json(
        { success: false, error: 'Audio file too large (max 25MB)' },
        { status: 400 }
      );
    }

    // Validate file type
    const validTypes = ['audio/webm', 'audio/mp4', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/m4a'];
    if (audioFile.type && !validTypes.some(t => audioFile.type.startsWith(t))) {
      // Be lenient — some browsers report different MIME types
      // Whisper will reject truly invalid formats anyway
    }

    // Send to OpenAI Whisper — bounded timeout + one retry on transient
    // failure (network blip / 429 / 5xx). A hung OpenAI call must not eat the
    // whole maxDuration window and leave the client spinning. FormData is
    // rebuilt per attempt (a consumed multipart stream can't be re-sent).
    const callWhisper = (): Promise<Response> => {
      const wf = new FormData();
      wf.append('file', audioFile, audioFile.name || 'recording.webm');
      wf.append('model', 'whisper-1');
      wf.append('language', 'en');
      return fetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}` },
        body: wf,
        signal: AbortSignal.timeout(35000), // 35s/attempt → ≤~71s worst case, under maxDuration=90
      });
    };

    let whisperResponse: Response | null = null;
    let lastErr: unknown = null;
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const r = await callWhisper();
        // Retry once on transient server-side failure
        if ((r.status === 429 || r.status >= 500) && attempt === 1) {
          await new Promise((res) => setTimeout(res, 600));
          continue;
        }
        whisperResponse = r;
        break;
      } catch (err) {
        lastErr = err; // network error or AbortSignal timeout
        if (attempt === 1) {
          await new Promise((res) => setTimeout(res, 600));
          continue;
        }
      }
    }

    if (!whisperResponse) {
      console.error('[Transcribe] Whisper unreachable after retry:', lastErr);
      return NextResponse.json(
        { success: false, error: 'Transcription timed out — please try again' },
        { status: 504 }
      );
    }

    if (!whisperResponse.ok) {
      console.error('[Transcribe] Whisper API error:', whisperResponse.status);
      return NextResponse.json(
        { success: false, error: 'Transcription failed' },
        { status: 502 }
      );
    }

    const result = await whisperResponse.json();
    const text = result.text?.trim();

    if (!text) {
      return NextResponse.json(
        { success: false, error: 'No speech detected in audio' },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true, text });

  } catch (error) {
    console.error('[Transcribe] Error:', error);
    return NextResponse.json(
      { success: false, error: 'Transcription failed' },
      { status: 500 }
    );
  }
}
