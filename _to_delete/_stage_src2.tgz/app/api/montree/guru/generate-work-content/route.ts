// app/api/montree/guru/generate-work-content/route.ts
// AI-powered content generation for new curriculum works
// Teacher provides work name + area + optional prompt → Sonnet generates all fields

import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase-client';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { anthropic, AI_ENABLED, AI_MODEL } from '@/lib/ai/anthropic';
import { resolveReportModel } from '@/lib/montree/reports/resolve-model';


// Railway/Next.js default serverless timeout is 15s. AI calls can
// exceed that and return 503 (Service Unavailable). 120s gives the
// route enough headroom while still bounded.
export const maxDuration = 120;

const GENERATE_CONTENT_TOOL = {
  name: 'generate_work_content' as const,
  description: 'Generate comprehensive Montessori curriculum content for a work/activity.',
  input_schema: {
    type: 'object' as const,
    properties: {
      description: {
        type: 'string',
        description: 'Professional 1-2 sentence description of this Montessori work for teachers.',
      },
      parent_description: {
        type: 'string',
        description: 'Warm, accessible 1-2 sentence explanation for parents who may not know Montessori terminology.',
      },
      why_it_matters: {
        type: 'string',
        description: 'Brief explanation of the developmental significance of this work (cognitive, motor, social-emotional benefits).',
      },
      quick_guide: {
        type: 'string',
        description: 'Step-by-step presentation guide for teachers (numbered steps, concise, actionable).',
      },
      materials: {
        type: 'array',
        items: { type: 'string' },
        description: 'List of materials needed (e.g., "Pink Tower (10 cubes)", "Small mat").',
      },
      direct_aims: {
        type: 'array',
        items: { type: 'string' },
        description: 'Direct aims of this work (what the child explicitly learns).',
      },
      presentation_steps: {
        type: 'array',
        items: { type: 'string' },
        description: 'Ordered presentation steps for the teacher.',
      },
    },
    required: ['description', 'parent_description', 'why_it_matters', 'quick_guide', 'materials', 'direct_aims', 'presentation_steps'],
  },
};

export async function POST(request: NextRequest) {
  try {
    const auth = await verifySchoolRequest(request);
    if (auth instanceof NextResponse) return auth;

    const body = await request.json();
    const { work_name, area, teacher_prompt, media_id } = body;
    const locale = ['en', 'zh'].includes(body.locale) ? body.locale : 'en';

    if (!work_name || typeof work_name !== 'string' || work_name.length > 200) {
      return NextResponse.json({ success: false, error: 'Valid work_name required (max 200 chars)' }, { status: 400 });
    }

    const validAreas = ['practical_life', 'sensorial', 'mathematics', 'language', 'cultural'];
    if (!area || !validAreas.includes(area)) {
      return NextResponse.json({ success: false, error: 'Valid area required' }, { status: 400 });
    }

    if (!AI_ENABLED || !anthropic) {
      return NextResponse.json({ success: false, error: 'AI features not enabled' }, { status: 503 });
    }

    // Check for duplicate work in classroom
    const supabase = getSupabase();

    // TIER GATE: generating curriculum content is a Sonnet-quality teacher tool.
    const aiTier = await resolveReportModel(supabase, auth.schoolId);
    if (aiTier.tier === 'free' || !aiTier.model) {
      return NextResponse.json(
        {
          success: false,
          error: 'Generating work content requires an active AI tier',
          tier: aiTier.tier,
          requires_upgrade: true,
          upgrade_url: '/montree/admin/billing',
          feature: 'generate_work_content',
        },
        { status: 402 }
      );
    }

    let duplicateWarning: string | null = null;

    if (auth.classroomId) {
      try {
        // Sanitize for ILIKE (escape special chars)
        const sanitized = work_name.trim().replace(/[%_\\]/g, '\\$&');
        const { data: existing } = await supabase
          .from('montree_classroom_curriculum_works')
          .select('name')
          .eq('classroom_id', auth.classroomId)
          .eq('is_active', true)
          .ilike('name', `%${sanitized}%`)
          .limit(3);

        if (existing && existing.length > 0) {
          const names = existing.map(w => w.name).join(', ');
          duplicateWarning = (() => {
            const L: Record<string, string> = {
              zh: `教室中已有类似的工作: ${names}`,
              es: `Ya existen trabajos similares en tu aula: ${names}`,
            };
            return L[locale || 'en'] || `Similar works already exist in your classroom: ${names}`;
          })();
        }
      } catch {
        // Non-fatal
      }
    }

    const langInstruction = (() => {
      const L: Record<string, string> = {
        zh: 'Write ALL content in Simplified Chinese.',
        es: 'Write ALL content in Spanish.',
      };
      return L[locale || 'en'] || 'Write ALL content in English.';
    })();

    const teacherContext = teacher_prompt && typeof teacher_prompt === 'string'
      ? `\n\nTeacher's notes about this work: "${teacher_prompt.slice(0, 500)}"`
      : '';

    // Photo Audit calls this with the media_id of the photo being tagged.
    // Pull the photo's cached AI description so the generated guide is
    // informed by what's actually in the classroom photo — not just the
    // work name. school_id scope is defense-in-depth (the draft is only
    // prompt context, but never read another school's media).
    let photoContext = '';
    if (media_id && typeof media_id === 'string') {
      try {
        const { data: mediaRow } = await supabase
          .from('montree_media')
          .select('sonnet_draft')
          .eq('id', media_id)
          .eq('school_id', auth.schoolId)
          .maybeSingle();
        const draft = (mediaRow?.sonnet_draft || {}) as Record<string, unknown>;
        const vd = typeof draft.visual_description === 'string' ? draft.visual_description.trim() : '';
        const km = Array.isArray(draft.key_materials)
          ? (draft.key_materials as unknown[]).filter((m): m is string => typeof m === 'string' && m.trim().length > 0)
          : [];
        if (vd) photoContext += `\n\nObserved in a real classroom photo of this work:\n"${vd.slice(0, 800)}"`;
        if (km.length) photoContext += `\nMaterials visible in the photo: ${km.slice(0, 12).join(', ')}`;
        if (photoContext) {
          photoContext += `\n\nGround the content in what the photo actually shows. Do not contradict the observed photo.`;
        }
      } catch {
        // Non-fatal — fall back to name-only generation.
      }
    }

    const systemPrompt = `You are an experienced AMI-trained Montessori teacher creating curriculum content for a new work.

${langInstruction}

Generate comprehensive, professional content for this Montessori work. Be specific, practical, and warm.
- Description: Professional but accessible
- Parent description: Assume zero Montessori knowledge, warm tone
- Why it matters: Connect to child development (cognitive, motor, social-emotional)
- Quick guide: Numbered steps a teacher can follow immediately
- Materials: Specific items needed
- Aims: What the child explicitly learns
- Presentation steps: Detailed ordered steps for showing the child${teacherContext}${photoContext}`;

    // Call AI with tool_use for structured output. Model is tier-aware.
    let timeoutHandle: ReturnType<typeof setTimeout> | undefined;
    const apiPromise = anthropic.messages.create({
      model: aiTier.model,
      max_tokens: 1200,
      system: systemPrompt,
      tools: [GENERATE_CONTENT_TOOL],
      tool_choice: { type: 'tool', name: 'generate_work_content' },
      messages: [{
        role: 'user',
        content: `Generate curriculum content for the Montessori work "${work_name.trim()}" in the ${area.replace('_', ' ')} area.`,
      }],
    });

    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutHandle = setTimeout(() => reject(new Error('Content generation took too long')), 45000);
    });

    const message = await Promise.race([apiPromise, timeoutPromise]).finally(() => {
      clearTimeout(timeoutHandle!);
    });

    const toolBlock = message.content.find(b => b.type === 'tool_use');
    if (!toolBlock || toolBlock.type !== 'tool_use') {
      return NextResponse.json({ success: false, error: 'Failed to generate content' }, { status: 500 });
    }

    const raw = toolBlock.input as Record<string, unknown>;

    // Validate and sanitize output
    const content = {
      description: typeof raw.description === 'string' ? raw.description.slice(0, 500) : '',
      parent_description: typeof raw.parent_description === 'string' ? raw.parent_description.slice(0, 500) : '',
      why_it_matters: typeof raw.why_it_matters === 'string' ? raw.why_it_matters.slice(0, 500) : '',
      quick_guide: typeof raw.quick_guide === 'string' ? raw.quick_guide.slice(0, 2000) : '',
      materials: Array.isArray(raw.materials) ? raw.materials.filter(m => typeof m === 'string').slice(0, 20) : [],
      direct_aims: Array.isArray(raw.direct_aims) ? raw.direct_aims.filter(a => typeof a === 'string').slice(0, 10) : [],
      presentation_steps: Array.isArray(raw.presentation_steps) ? raw.presentation_steps.filter(s => typeof s === 'string').slice(0, 15) : [],
    };

    return NextResponse.json({
      success: true,
      content,
      duplicate_warning: duplicateWarning,
    });

  } catch (error) {
    console.error('[GenerateWorkContent] Error:', error);
    return NextResponse.json({ success: false, error: 'Failed to generate content' }, { status: 500 });
  }
}
