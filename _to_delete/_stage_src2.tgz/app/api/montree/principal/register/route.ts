// /api/montree/principal/register/route.ts
// Session 105: Principal registration - creates school + principal account
import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase-client';
import { hashPassword } from '@/lib/montree/password';
import { validatePassword } from '@/lib/password-policy';
import { checkRateLimit } from '@/lib/rate-limiter';
import { getClientIP } from '@/lib/montree/audit-logger';
import { createMontreeToken, setMontreeAuthCookie } from '@/lib/montree/server-auth';
import { redeemOutreachCode } from '@/lib/montree/outreach/redeem';
import { checkBlacklistTripwire } from '@/lib/montree/outreach/blacklist-tripwire';
import { stampSchoolAttribution } from '@/lib/montree/outreach/stamp-attribution';
import { getLocationFromRequest } from '@/lib/ip-geolocation';
import { DEFAULTS } from '@/lib/montree/constants';

function generateSlug(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').substring(0, 50);
}

export async function POST(request: NextRequest) {
  try {
    const supabase = getSupabase();
    const ip = getClientIP(request.headers);

    // Rate limiting (3 attempts per IP per 15 min for registration)
    const { allowed, retryAfterSeconds } = await checkRateLimit(
      supabase, ip, '/api/montree/principal/register', 3, 15
    );
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many attempts. Please try again later.' },
        { status: 429, headers: { 'Retry-After': String(retryAfterSeconds) } }
      );
    }

    const { schoolName, principalName, email, password, referralCode } = await request.json();

    // Validate
    if (!schoolName?.trim()) {
      return NextResponse.json({ error: 'School name is required' }, { status: 400 });
    }
    if (!principalName?.trim()) {
      return NextResponse.json({ error: 'Principal name is required' }, { status: 400 });
    }
    if (!email?.trim()) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 });
    }
    if (!password) {
      return NextResponse.json({ error: 'Password is required' }, { status: 400 });
    }

    const validation = validatePassword(password);
    if (!validation.valid) {
      return NextResponse.json(
        { error: `Password does not meet requirements: ${validation.errors.join(', ')}` },
        { status: 400 }
      );
    }

    // Check if email already exists
    const { data: existingAdmin } = await supabase
      .from('montree_school_admins')
      .select('id')
      .eq('email', email.trim().toLowerCase())
      .maybeSingle();

    if (existingAdmin) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 400 });
    }

    // Check if slug already exists
    const slug = generateSlug(schoolName);
    const { data: existingSchool } = await supabase
      .from('montree_schools')
      .select('id')
      .eq('slug', slug)
      .maybeSingle();

    if (existingSchool) {
      return NextResponse.json({ error: 'A school with this name already exists' }, { status: 400 });
    }

    // 🚨 Launch pricing (Jul 6 2026 — plan amendment A1): every 'trialing'
    // school MUST carry a trial_ends_at. The tier resolver's three-way trial
    // branch reads it: future → Sonnet (Premium trial), past → free (choose a
    // plan), NULL → Haiku legacy floor. Writing it here keeps this path off the
    // NULL floor so a fresh principal signup gets the real Premium trial.
    // DEFAULTS.TRIAL_DAYS (= 7) is the single source of truth for trial length.
    const trialEndsAt = new Date(Date.now() + DEFAULTS.TRIAL_DAYS * 24 * 60 * 60 * 1000);

    // 1. Create school
    const { data: school, error: schoolError } = await supabase
      .from('montree_schools')
      .insert({
        name: schoolName.trim(),
        slug,
        owner_email: email.trim().toLowerCase(),
        owner_name: principalName.trim(),
        subscription_status: 'trialing',
        trial_ends_at: trialEndsAt.toISOString(),
        plan_type: 'school',
        subscription_tier: 'free',
        is_active: true,
        // Montage on by default for new schools (Jul 27 2026). Mirrors the DB
        // default flipped in migrations/302_montage_default_on.sql — set here too
        // so the flag is correct even on a database where 302 has not been run.
        montage_enabled: true,
      })
      .select()
      .single();

    if (schoolError) {
      console.error('School creation error:', schoolError);
      return NextResponse.json({ error: 'Failed to create school' }, { status: 500 });
    }

    // 2. Create principal account (bcrypt)
    const passwordHash = await hashPassword(password);
    const { data: principal, error: adminError } = await supabase
      .from('montree_school_admins')
      .insert({
        school_id: school.id,
        email: email.trim().toLowerCase(),
        password_hash: passwordHash,
        name: principalName.trim(),
        role: 'principal',
        is_active: true,
      })
      .select()
      .single();

    if (adminError) {
      console.error('Principal creation error:', adminError);
      // Rollback school creation
      await supabase.from('montree_schools').delete().eq('id', school.id);
      return NextResponse.json({ error: 'Failed to create principal account' }, { status: 500 });
    }

    // Outreach attribution (China cold-email campaign, Jul 2026): if the
    // signup carried a referral code (typed, or pre-filled from the
    // montree_ref cookie set by /welcome/[code]), mark that outreach row as
    // registered. Fire-and-forget — a redeem failure must NEVER block
    // registration (handoff hard rule). Idempotent inside the helper.
    if (referralCode && typeof referralCode === 'string') {
      void redeemOutreachCode(supabase, referralCode, school.id).catch((err) =>
        console.error('[register] outreach redeem failed:', err)
      );
    }

    // Blacklist signup tripwire (fire-and-forget observation): if this signup's
    // email / domain matches a [BLACKLIST]-marked outreach contact, email
    // Tredoux. NEVER blocks registration — the helper swallows every error.
    void checkBlacklistTripwire(supabase, {
      email: email.trim(),
      schoolName: schoolName.trim(),
      schoolId: school.id,
      source: 'principal_register',
    }).catch((err) => console.error('[register] blacklist tripwire failed:', err));

    // Ad-geo attribution (Jul 7 2026): stamp the school with its first-touch
    // acquisition source from the montree_attrib cookie. Fire-and-forget — NEVER
    // blocks registration. Parity with try/instant's stamp.
    void stampSchoolAttribution(supabase, request, school.id).catch((err) =>
      console.error('[register] attrib stamp failed:', err)
    );

    // signup_country parity: try/instant records signup geolocation; register
    // never did. Fire-and-forget analytics — must not block or fail signup.
    void (async () => {
      try {
        const location = await getLocationFromRequest(request);
        if (location.country) {
          await supabase
            .from('montree_schools')
            .update({
              signup_country: location.country,
              signup_country_code: location.countryCode,
              signup_city: location.city,
              signup_region: location.region,
              signup_ip: location.ip,
              signup_timezone: location.timezone,
            })
            .eq('id', school.id);
        }
      } catch (err) {
        console.error('[register] signup geo failed:', err);
      }
    })();

    // Log the principal in immediately by minting a session token + cookie.
    // The follow-on /principal/setup call requires this session (it scopes
    // classroom/teacher creation to the authenticated school). Without this,
    // setup had to run unauthenticated — a critical open-write IDOR (closed
    // 2026-06-10).
    const token = await createMontreeToken({
      sub: principal.id,
      schoolId: school.id,
      role: 'principal',
    });
    const response = NextResponse.json({
      success: true,
      school: {
        id: school.id,
        name: school.name,
        slug: school.slug,
      },
      principal: {
        id: principal.id,
        name: principal.name,
        email: principal.email,
        role: principal.role,
      },
    });
    setMontreeAuthCookie(response, token, 'principal');
    return response;

  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
