// app/api/montree/analysis/route.ts
// API for generating weekly child analysis
// GET: Get cached analysis for a child/week
// POST: Generate new analysis
// Session 126: Fixed to read env vars at runtime
// Updated: Now fetches FULL learning journey + notes from work_sessions

import { NextRequest, NextResponse } from 'next/server';
import { getSupabase } from '@/lib/supabase-client';
import { analyzeWeeklyProgress, WeeklyAnalysisResult } from '@/lib/montree/ai';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { verifyChildBelongsToSchool } from '@/lib/montree/verify-child-access';

// ============================================
// GET: Retrieve cached analysis
// ============================================
export async function GET(request: NextRequest) {
  try {
    const auth = await verifySchoolRequest(request);
    if (auth instanceof NextResponse) return auth;

    const { searchParams } = new URL(request.url);
    const childId = searchParams.get('child_id');
    const weekStart = searchParams.get('week_start');

    if (!childId) {
      return NextResponse.json(
        { success: false, error: 'child_id is required' },
        { status: 400 }
      );
    }

    // Verify child belongs to this school
    const accessCheck = await verifyChildBelongsToSchool(childId, auth.schoolId);
    if (!accessCheck.allowed) {
      return NextResponse.json(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    const supabase = getSupabase();

    let query = supabase
      .from('montree_weekly_analysis')
      .select('*')
      .eq('child_id', childId)
      .order('week_start', { ascending: false });

    if (weekStart) {
      query = query.eq('week_start', weekStart);
    } else {
      query = query.limit(1);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching analysis:', error.message, error.code);
      return NextResponse.json(
        { success: false, error: 'Internal server error' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      analysis: data?.[0] || null,
    });

  } catch (error) {
    console.error('Analysis GET error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ============================================
// POST: Generate new analysis
// ============================================
export async function POST(request: NextRequest) {
  try {
    const auth = await verifySchoolRequest(request);
    if (auth instanceof NextResponse) return auth;

    const body = await request.json();
    const { child_id, week_start, week_end, force_regenerate } = body;

    if (!child_id || !week_start || !week_end) {
      return NextResponse.json(
        { success: false, error: 'child_id, week_start, and week_end are required' },
        { status: 400 }
      );
    }

    const supabase = getSupabase();

    // Verify child belongs to this school
    const accessCheck = await verifyChildBelongsToSchool(child_id, auth.schoolId);
    if (!accessCheck.allowed) {
      return NextResponse.json(
        { success: false, error: 'Access denied' },
        { status: 403 }
      );
    }

    // Check for existing analysis
    if (!force_regenerate) {
      const { data: existing } = await supabase
        .from('montree_weekly_analysis')
        .select('id, generated_at')
        .eq('child_id', child_id)
        .eq('week_start', week_start)
        .maybeSingle();

      if (existing) {
        return NextResponse.json({
          success: true,
          message: 'Analysis already exists',
          analysis_id: existing.id,
          generated_at: existing.generated_at,
          cached: true,
        });
      }
    }

    // Fetch child data
    const { data: child, error: childError } = await supabase
      .from('montree_children')
      .select('id, name, date_of_birth, classroom_id')
      .eq('id', child_id)
      .maybeSingle();

    if (childError || !child) {
      return NextResponse.json(
        { success: false, error: 'Child not found' },
        { status: 404 }
      );
    }

    // Fetch all child data in parallel (4 independent queries)
    const [progressResult, historicalResult, sessionsResult, curriculumResult] = await Promise.all([
      // Week's progress. 🚨 Perf Tier 3.3 (PERF_HEALTH_CHECK.md) — explicit
      // column list. Result is used internally below (lines 209-230) to build
      // the analysis payload via {work_name, area, status, notes, created_at}
      // — every other column on montree_child_progress (id, child_id, work_key,
      // confirmed_count, first_presented_at, last_practiced_at, mastered_at,
      // classroom_id, updated_at, source, is_focus, is_extra, …) was a wasted
      // round trip. Narrowing cuts row payload ~70%.
      supabase
        .from('montree_child_progress')
        .select('work_name, area, status, notes, created_at')
        .eq('child_id', child_id)
        .gte('created_at', week_start)
        .lte('created_at', week_end + 'T23:59:59'),
      // Full historical progress (entire learning journey)
      supabase
        .from('montree_child_progress')
        .select('work_name, area, status, created_at, notes')
        .eq('child_id', child_id)
        .lt('created_at', week_start)
        .order('created_at', { ascending: true }),
      // All teacher observations/notes from work_sessions
      supabase
        .from('montree_work_sessions')
        .select('work_name, area, notes, observed_at, session_type, duration_minutes')
        .eq('child_id', child_id)
        .order('observed_at', { ascending: true }),
      // Available curriculum works
      supabase
        .from('montree_classroom_curriculum_works')
        .select('id, name, area, sequence_order')
        .eq('classroom_id', child.classroom_id),
    ]);

    const progress = progressResult.data;
    const historicalProgress = historicalResult.data;
    const workSessions = sessionsResult.data;
    const curriculum = curriculumResult.data;

    if (progressResult.error) {
      console.error('Error fetching progress:', progressResult.error);
      return NextResponse.json(
        { success: false, error: 'Failed to fetch progress data' },
        { status: 500 }
      );
    }

    // Create a map of notes by work_name for easy lookup
    const notesByWork: Record<string, string[]> = {};
    for (const session of workSessions || []) {
      if (session.notes && session.work_name) {
        if (!notesByWork[session.work_name]) {
          notesByWork[session.work_name] = [];
        }
        const dateStr = new Date(session.observed_at).toLocaleDateString();
        notesByWork[session.work_name].push(`[${dateStr}] ${session.notes}`);
      }
    }

    // Run analysis with full learning journey data
    const analysisResult = analyzeWeeklyProgress({
      child: {
        id: child.id,
        name: child.name,
        date_of_birth: child.date_of_birth,
        classroom_id: child.classroom_id,
      },
      weekStart: week_start,
      weekEnd: week_end,
      // Current week's progress with merged notes from work_sessions
      progress: (progress || []).map(p => ({
        work_name: p.work_name,
        area: p.area,
        status: p.status,
        // Combine notes from progress record AND work_sessions
        notes: [
          p.notes,
          ...(notesByWork[p.work_name] || [])
        ].filter(Boolean).join('\n'),
        date: p.created_at,
        duration_minutes: p.duration_minutes,
        repetition_count: p.repetition_count,
      })),
      // FULL historical progress (entire learning journey)
      historicalProgress: (historicalProgress || []).map(p => ({
        work_name: p.work_name,
        area: p.area,
        status: p.status,
        date: p.created_at,
        // Include historical notes too
        notes: [
          p.notes,
          ...(notesByWork[p.work_name] || [])
        ].filter(Boolean).join('\n'),
      })),
      // All work sessions for detailed observation history
      observationHistory: (workSessions || []).map(s => ({
        work_name: s.work_name,
        area: s.area,
        notes: s.notes,
        date: s.observed_at,
        session_type: s.session_type,
        duration_minutes: s.duration_minutes,
      })),
      availableWorks: (curriculum || []).map(w => ({
        id: w.id,
        name: w.name,
        area: w.area,
        sequence_order: w.sequence_order,
      })),
    });

    // Save to database
    const { data: saved, error: saveError } = await supabase
      .from('montree_weekly_analysis')
      .upsert({
        child_id,
        classroom_id: child.classroom_id,
        week_start,
        week_end,
        area_distribution: analysisResult.area_distribution,
        expected_distribution: analysisResult.expected_distribution,
        total_works_count: analysisResult.total_works,
        avg_duration_minutes: analysisResult.avg_duration_minutes,
        expected_duration_minutes: analysisResult.expected_duration_minutes,
        concentration_score: analysisResult.concentration_score,
        repetition_patterns: analysisResult.repetition_highlights,
        avoidance_patterns: analysisResult.areas_needing_attention,
        breakthrough_indicators: [],
        active_sensitive_periods: analysisResult.detected_sensitive_periods.map(p => p.period_id),
        sensitive_period_evidence: analysisResult.detected_sensitive_periods,
        red_flags: analysisResult.red_flags,
        yellow_flags: analysisResult.yellow_flags,
        recommended_works: analysisResult.recommended_works,
        teacher_summary: analysisResult.teacher_summary,
        parent_summary: analysisResult.parent_summary,
        psychological_profile: analysisResult.psychological_profile,
        generated_at: new Date().toISOString(),
      }, {
        onConflict: 'child_id,week_start',
      })
      .select()
      .maybeSingle();

    if (saveError) {
      console.error('Error saving analysis:', saveError.message, saveError.code);
      // Return the analysis even if save failed
      return NextResponse.json({
        success: true,
        analysis: analysisResult,
        saved: false,
        save_error: 'Failed to save analysis',
      });
    }

    return NextResponse.json({
      success: true,
      analysis: analysisResult,
      analysis_id: saved?.id,
      saved: true,
    });

  } catch (error) {
    console.error('Analysis POST error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
