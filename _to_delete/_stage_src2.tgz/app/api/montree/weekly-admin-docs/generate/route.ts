// app/api/montree/weekly-admin-docs/generate/route.ts
// POST: Generate Weekly Summary or Weekly Plan .docx from saved notes + progress data

import { NextRequest, NextResponse } from 'next/server';
import { verifySchoolRequest } from '@/lib/montree/verify-request';
import { getSupabase } from '@/lib/supabase-client';
import { isFeatureEnabled } from '@/lib/montree/features/server';
import { sortChildrenByCustomOrder } from '@/lib/montree/weekly-admin/child-order';
import {
  generateWeeklySummary,
  generateWeeklyPlan,
  packDocument,
  type ChildNotes,
} from '@/lib/montree/weekly-admin/doc-generator';

export async function POST(request: NextRequest) {
  const auth = await verifySchoolRequest(request);
  if (auth instanceof NextResponse) return auth;

  // Feature gate: weekly_admin_docs must be enabled for this school
  const supabaseCheck = getSupabase();
  if (!await isFeatureEnabled(supabaseCheck, auth.schoolId, 'weekly_admin_docs')) {
    return NextResponse.json({ error: 'Weekly admin docs feature is not enabled for this school' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const classroomId: string = body.classroom_id || auth.classroomId;
    const weekStart: string = body.week_start;
    const docType: string = body.doc_type; // 'summary' or 'plan'
    const locale: string = body.locale || 'en'; // 'en' or 'zh'

    if (!classroomId) {
      return NextResponse.json({ error: 'classroom_id required' }, { status: 400 });
    }
    if (!weekStart) {
      return NextResponse.json({ error: 'week_start required' }, { status: 400 });
    }
    if (!['summary', 'plan'].includes(docType)) {
      return NextResponse.json({ error: 'doc_type must be "summary" or "plan"' }, { status: 400 });
    }

    // Validate weekStart is a Monday
    const parsed = new Date(`${weekStart}T00:00:00Z`);
    if (isNaN(parsed.getTime()) || parsed.getUTCDay() !== 1) {
      return NextResponse.json({ error: 'week_start must be a valid Monday date' }, { status: 400 });
    }

    const supabase = getSupabase();

    // Verify classroom belongs to teacher's school
    const { data: classroom } = await supabase
      .from('montree_classrooms')
      .select('school_id')
      .eq('id', classroomId)
      .maybeSingle();

    if (!classroom || classroom.school_id !== auth.schoolId) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Calculate week boundaries for progress query
    const weekEndDate = new Date(parsed.getTime() + 7 * 24 * 60 * 60 * 1000);
    const weekEnd = weekEndDate.toISOString().slice(0, 10);

    // Step 1: Fetch children + notes in parallel
    const [childrenRes, notesRes] = await Promise.all([
      // 1. All children in classroom
      supabase
        .from('montree_children')
        .select('id, name')
        .eq('classroom_id', classroomId)
        .eq('is_active', true)
        .order('name', { ascending: true }),

      // 2. All saved notes for this week + doc type
      supabase
        .from('montree_weekly_admin_notes')
        .select('*')
        .eq('classroom_id', classroomId)
        .eq('week_start', weekStart)
        .eq('doc_type', docType),
    ]);

    if (childrenRes.error) {
      console.error('weekly-admin-docs/generate children error:', childrenRes.error.message);
      return NextResponse.json({ error: 'Failed to fetch children' }, { status: 500 });
    }

    if (notesRes.error) {
      console.error('weekly-admin-docs/generate notes error:', notesRes.error.message);
      return NextResponse.json({ error: 'Failed to fetch notes' }, { status: 500 });
    }

    // Apply custom classroom order (matches physical seating arrangement)
    const children = sortChildrenByCustomOrder(childrenRes.data || []);
    const notes = notesRes.data || [];

    // Build notes lookup: child_id -> { area -> note }
    const notesMap = new Map<string, Map<string | null, typeof notes[0]>>();
    for (const note of notes) {
      if (!notesMap.has(note.child_id)) {
        notesMap.set(note.child_id, new Map());
      }
      notesMap.get(note.child_id)!.set(note.area, note);
    }

    // Assemble ChildNotes for the doc generator
    const childNotes: ChildNotes[] = children.map((child: { id: string; name: string }) => {
      const childNotesMap = notesMap.get(child.id);

      if (docType === 'summary') {
        // Summary: overall English + Chinese notes (area=null)
        const summaryNote = childNotesMap?.get(null);

        // Use locale-appropriate content as the primary display
        const englishSummary = (() => {
          const defaultTexts: Record<string, string> = {
            zh: '本周没有记录到活动。',
            es: 'No se registraron actividades esta semana.',
          };
          const defaultText = defaultTexts[locale || 'en'] || 'No recorded activities this week.';
          if (locale === 'zh') return summaryNote?.chinese_text || summaryNote?.english_text || defaultText;
          return summaryNote?.english_text || defaultText;
        })();

        return {
          childId: child.id,
          childName: child.name,
          englishSummary,
          chineseSummary: '', // Single-language mode — content is in englishSummary
        };
      } else {
        // Plan: per-area English work names + overall Chinese note + additional notes
        const areas = ['practical_life', 'sensorial', 'mathematics', 'language', 'cultural'] as const;
        const planAreas: ChildNotes['planAreas'] = {};

        for (const area of areas) {
          const areaNote = childNotesMap?.get(area);
          // Use Chinese work name when locale is zh and chinese_text exists
          const workText = (() => {
            if (locale === 'zh') return areaNote?.chinese_text || areaNote?.english_text || '';
            return areaNote?.english_text || '';
          })();
          planAreas[area] = {
            en: workText,
          };
        }

        // Overall Chinese developmental note (stored with area=null)
        const overallNote = childNotesMap?.get(null);
        // Additional notes text (stored with area='notes')
        const notesEntry = childNotesMap?.get('notes');

        return {
          childId: child.id,
          childName: child.name,
          planAreas,
          chineseNote: overallNote?.chinese_text || '',
          notesText: notesEntry?.english_text || '',
        };
      }
    });

    // Generate document
    const weekEndForLabel = new Date(parsed.getTime() + 6 * 24 * 60 * 60 * 1000);
    const weekNumber = getWeekNumber(parsed);
    const weekLabel = `W${weekNumber} (${weekStart} \u2013 ${weekEndForLabel.toISOString().slice(0, 10)})`;

    const doc = docType === 'summary'
      ? generateWeeklySummary(childNotes, weekLabel)
      : generateWeeklyPlan(childNotes, `W${weekNumber}`);

    const buffer = await packDocument(doc);

    // Return as downloadable .docx
    const filename = docType === 'summary'
      ? `Weekly_Summary_${weekStart}.docx`
      : `Weekly_Plan_${weekStart}.docx`;

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': buffer.length.toString(),
      },
    });
  } catch (err) {
    console.error('weekly-admin-docs/generate exception:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ─── Helpers ─────────────────────────────────────────────────

/** Get ISO week number from a date. */
function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}
