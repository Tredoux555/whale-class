// app/montree/dashboard/reports/view/page.tsx
// Native-compatible report view using query params
// Usage: /montree/dashboard/reports/view?id=xxx
// This is used in native builds where dynamic [id] routes don't work

'use client';

import { useSearchParams, useRouter } from 'next/navigation';
import { Suspense, useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { useI18n, type TranslationKey } from '@/lib/montree/i18n';

function ReportViewContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const reportId = searchParams.get('id');
  const { t } = useI18n();

  // Minimal state for loading
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    if (!reportId) {
      setError(t('reportView.noReportId' as TranslationKey));
      setLoading(false);
      return;
    }
    
    // For web, redirect to the proper dynamic route
    // For native, this page will be enhanced with SQLite queries
    if (typeof window !== 'undefined') {
      const isNative = (window as any).Capacitor?.isNativePlatform?.();
      if (!isNative) {
        // Web: redirect to dynamic route
        router.replace(`/montree/dashboard/reports/${reportId}`);
        return;
      }
    }
    
    setLoading(false);
  }, [reportId, router]);
  
  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a1a0f] flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  if (error || !reportId) {
    return (
      <div className="min-h-screen bg-[#0a1a0f] flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4">😕</div>
          <p className="text-white/60 mb-4">{error || t('reportView.noReportId' as TranslationKey)}</p>
          <Link href="/montree/dashboard/weekly-wrap" className="text-[#34d399] hover:underline">
            ← {t('reportView.backToReports' as TranslationKey)}
          </Link>
        </div>
      </div>
    );
  }

  // Native placeholder - will be replaced with SQLite queries in Phase 2
  return (
    <div className="min-h-screen bg-[#0a1a0f] p-4">
      <div className="max-w-2xl mx-auto">
        <Link href="/montree/dashboard/weekly-wrap" className="text-[#34d399] mb-4 inline-block">
          ← {t('reportView.backToReports' as TranslationKey)}
        </Link>
        <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-xl p-6">
          <h1 className="text-xl font-bold text-white/95 mb-4">{t('reportView.title' as TranslationKey)}</h1>
          <p className="text-white/60">{t('reportView.reportId' as TranslationKey)}: {reportId}</p>
          <p className="text-white/40 text-sm mt-4">
            {t('reportView.nativeComingSoon' as TranslationKey)}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function ReportViewPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-[#0a1a0f] flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-4 border-emerald-500 border-t-transparent" />
      </div>
    }>
      <ReportViewContent />
    </Suspense>
  );
}
