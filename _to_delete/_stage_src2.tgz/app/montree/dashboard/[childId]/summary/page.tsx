// app/montree/dashboard/[childId]/summary/page.tsx
// Teacher Summary - Weekly/Monthly insights for a child
// Testing Week - Phase 4

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { toast } from 'sonner';
import { useI18n } from '@/lib/montree/i18n';
import { AREA_CONFIG } from '@/lib/montree/types';
import AreaBadge, { normalizeArea } from '@/components/montree/shared/AreaBadge';

// ============================================
// TYPES
// ============================================

interface ChildData {
  id: string;
  name: string;
  classroom_id: string;
}

interface ProgressData {
  work_name: string;
  area: string;
  status: string;
  created_at: string;
  notes?: string;
}

interface AreaStats {
  area: string;
  count: number;
  works: string[];
}

interface SummaryData {
  child: ChildData;
  period: string;
  totalWorksThisPeriod: number;
  areasWorked: AreaStats[];
  areasNeglected: string[];
  statusBreakdown: {
    presented: number;
    practicing: number;
    mastered: number;
  };
  recentProgress: ProgressData[];
}

type TimePeriod = 'week' | 'month';

// ============================================
// COMPONENT
// ============================================

export default function TeacherSummaryPage() {
  const params = useParams();
  const router = useRouter();
  const childId = params.childId as string;
  const { t } = useI18n();

  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<SummaryData | null>(null);
  const [period, setPeriod] = useState<TimePeriod>('week');
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ALL_AREAS = ['practical_life', 'sensorial', 'mathematics', 'language', 'cultural'];

  // ============================================
  // FETCH DATA
  // ============================================

  const fetchSummary = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Calculate date range
      const now = new Date();
      const startDate = new Date();
      if (period === 'week') {
        startDate.setDate(now.getDate() - 7);
      } else {
        startDate.setMonth(now.getMonth() - 1);
      }

      // Fetch child info
      const childRes = await fetch(`/api/montree/children?id=${childId}`);
      if (!childRes.ok) {
        setError(t('summary.childNotFound'));
        setLoading(false);
        return;
      }
      const childData = await childRes.json();

      if (!childData.children || childData.children.length === 0) {
        setError(t('summary.childNotFound'));
        setLoading(false);
        return;
      }

      const child = childData.children[0];

      // Fetch progress data
      const progressRes = await fetch(
        `/api/montree/progress?child_id=${childId}&from=${startDate.toISOString()}&to=${now.toISOString()}`
      );
      if (!progressRes.ok) {
        setError('Failed to load progress data');
        setLoading(false);
        return;
      }
      const progressData = await progressRes.json();
      const progress: ProgressData[] = progressData.progress || [];

      // Calculate area statistics
      const areaMap = new Map<string, { count: number; works: string[] }>();
      const statusCount = { presented: 0, practicing: 0, mastered: 0 };

      progress.forEach(p => {
        const area = p.area || 'unknown';
        const existing = areaMap.get(area) || { count: 0, works: [] };
        existing.count++;
        if (!existing.works.includes(p.work_name)) {
          existing.works.push(p.work_name);
        }
        areaMap.set(area, existing);

        // Count statuses
        if (p.status === 'presented') statusCount.presented++;
        else if (p.status === 'practicing') statusCount.practicing++;
        else if (p.status === 'mastered') statusCount.mastered++;
      });

      // Build area stats
      const areasWorked: AreaStats[] = [];
      areaMap.forEach((stats, area) => {
        areasWorked.push({ area, count: stats.count, works: stats.works });
      });
      areasWorked.sort((a, b) => b.count - a.count);

      // Find neglected areas
      const workedAreaNames = areasWorked.map(a => a.area);
      const neglected = ALL_AREAS.filter(a => !workedAreaNames.includes(a));

      setSummary({
        child,
        period: period === 'week' ? t('summary.past7Days') : t('summary.past30Days'),
        totalWorksThisPeriod: progress.length,
        areasWorked,
        areasNeglected: neglected,
        statusBreakdown: statusCount,
        recentProgress: progress.slice(0, 10),
      });
    } catch (err) {
      console.error('Failed to fetch summary:', err);
      setError(t('summary.loadError'));
    } finally {
      setLoading(false);
    }
  }, [childId, period]);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  // ============================================
  // AI INSIGHT
  // ============================================

  const generateAiInsight = async () => {
    if (!summary) return;

    setLoadingAi(true);
    setAiInsight(null);

    try {
      const question = `Based on this child's recent activity (${summary.period}), they have worked on ${summary.totalWorksThisPeriod} activities. Areas worked: ${summary.areasWorked.map(a => `${formatAreaName(a.area)} (${a.count})`).join(', ')}. ${summary.areasNeglected.length > 0 ? `Areas not touched: ${summary.areasNeglected.map(formatAreaName).join(', ')}.` : 'All areas covered.'} Status breakdown: ${summary.statusBreakdown.presented} presented, ${summary.statusBreakdown.practicing} practicing, ${summary.statusBreakdown.mastered} mastered. What patterns do you notice and what should the teacher focus on next?`;

      const res = await fetch('/api/montree/guru', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          child_id: childId,
          question,
        }),
      });

      const data = await res.json();

      if (data.success && data.insight) {
        setAiInsight(data.insight);
        toast.success(t('summary.insightsGenerated'));
      } else {
        setError(data.error || t('summary.insightsGenerateFailed'));
        toast.error(t('summary.insightsGenerateFailed'));
      }
    } catch (err) {
      console.error('AI insight error:', err);
      toast.error(t('summary.aiConnectError'));
    } finally {
      setLoadingAi(false);
    }
  };

  // ============================================
  // HELPERS
  // ============================================

  const formatAreaName = (area: string) => {
    return area
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const getAreaColor = (area: string) => {
    // Dark-register (Jul 16 sweep): uniform glass tile. Area colour is carried
    // by the inline AreaBadge, not a light full-card background.
    const config = AREA_CONFIG[normalizeArea(area)];
    return config ? 'bg-white/[0.04] text-white/85' : 'bg-white/[0.04] text-white/85';
  };

  // ============================================
  // RENDER
  // ============================================

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-10 w-10 border-4 border-[#34d399] border-t-transparent mb-4" />
          <p className="text-white/60">{t('summary.loading')}</p>
        </div>
      </div>
    );
  }

  if (error || !summary) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="text-center p-6">
          <div className="text-4xl mb-4">❌</div>
          <p className="text-white/60 mb-4">{error || t('summary.loadError')}</p>
          <button
            onClick={() => router.back()}
            className="px-4 py-2 bg-[#1D6B48] text-white rounded-lg hover:bg-[#236B4C]"
          >
            {t('summary.goBack')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Sub-header */}
      <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl px-4 py-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">📊</span>
            <div>
              <h1 className="font-bold text-white/95" style={{ fontFamily: 'var(--font-lora), Georgia, serif', fontWeight: 500 }}>
                {summary.child.name}&apos;s Summary
              </h1>
              <p className="text-xs text-white/50">{summary.period}</p>
            </div>
          </div>

          {/* Period toggle */}
          <div className="flex bg-black/30 rounded-lg p-1">
            <button
              onClick={() => setPeriod('week')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                period === 'week' ? 'bg-[#34d399]/15 text-[#34d399]' : 'text-white/60 hover:bg-white/10'
              }`}
            >
              {t('summary.week')}
            </button>
            <button
              onClick={() => setPeriod('month')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                period === 'month' ? 'bg-[#34d399]/15 text-[#34d399]' : 'text-white/60 hover:bg-white/10'
              }`}
            >
              {t('summary.month')}
            </button>
          </div>
        </div>
      </div>

      <main className="space-y-4 pb-24">
        {/* Overview Stats */}
        <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl p-4">
          <h2 className="font-bold text-white/90 mb-3">📊 {t('summary.overview')}</h2>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 bg-white/[0.04] rounded-xl">
              <div className="text-2xl font-bold text-[#34d399]">
                {summary.totalWorksThisPeriod}
              </div>
              <div className="text-xs text-white/50">{t('summary.totalActivities')}</div>
            </div>
            <div className="text-center p-3 bg-white/[0.04] rounded-xl">
              <div className="text-2xl font-bold text-emerald-300">
                {summary.statusBreakdown.mastered}
              </div>
              <div className="text-xs text-white/50">{t('summary.mastered')}</div>
            </div>
            <div className="text-center p-3 bg-white/[0.04] rounded-xl">
              <div className="text-2xl font-bold text-violet-300">
                {summary.areasWorked.length}
              </div>
              <div className="text-xs text-white/50">{t('summary.areasCovered')}</div>
            </div>
          </div>
        </div>

        {/* Areas Worked */}
        <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl p-4">
          <h2 className="font-bold text-white/90 mb-3">✅ {t('summary.areasWorkedOn')}</h2>
          {summary.areasWorked.length === 0 ? (
            <p className="text-white/40 text-center py-4">{t('summary.noWorkThisPeriod')}</p>
          ) : (
            <div className="space-y-2">
              {summary.areasWorked.map(area => (
                <div
                  key={area.area}
                  className={`p-3 rounded-xl border border-[rgba(52,211,153,0.12)] ${getAreaColor(area.area)}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium flex items-center gap-1.5">
                      <AreaBadge area={area.area} size="xs" /> {formatAreaName(area.area)}
                    </span>
                    <span className="text-sm font-bold">{area.count} {t('summary.activities')}</span>
                  </div>
                  <div className="text-sm text-white/55">
                    {area.works.slice(0, 3).join(', ')}
                    {area.works.length > 3 && ` +${area.works.length - 3} more`}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Neglected Areas */}
        {summary.areasNeglected.length > 0 && (
          <div className="bg-white/[0.06] rounded-2xl p-4 border border-[rgba(52,211,153,0.15)] border-l-4 border-l-amber-400">
            <h2 className="font-bold text-white/90 mb-3">⚠️ {t('summary.areasToConsider')}</h2>
            <p className="text-sm text-white/60 mb-2">
              {t('summary.areasNotWorked').replace('{period}', period)}
            </p>
            <div className="flex flex-wrap gap-2">
              {summary.areasNeglected.map(area => (
                <span
                  key={area}
                  className="px-3 py-1 bg-amber-500/15 text-amber-200 rounded-full text-sm"
                >
                  <AreaBadge area={area} size="xs" className="inline-block" /> {formatAreaName(area)}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Status Breakdown */}
        <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl p-4">
          <h2 className="font-bold text-white/90 mb-3">📈 {t('summary.progressBreakdown')}</h2>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/60">{t('summary.presented')}</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-yellow-400"
                    style={{
                      width: `${summary.totalWorksThisPeriod > 0 ? (summary.statusBreakdown.presented / summary.totalWorksThisPeriod) * 100 : 0}%`,
                    }}
                  />
                </div>
                <span className="text-sm font-medium w-8 text-right text-white/80">
                  {summary.statusBreakdown.presented}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/60">{t('summary.practicing')}</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-400"
                    style={{
                      width: `${summary.totalWorksThisPeriod > 0 ? (summary.statusBreakdown.practicing / summary.totalWorksThisPeriod) * 100 : 0}%`,
                    }}
                  />
                </div>
                <span className="text-sm font-medium w-8 text-right text-white/80">
                  {summary.statusBreakdown.practicing}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-white/60">{t('summary.mastered')}</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-400"
                    style={{
                      width: `${summary.totalWorksThisPeriod > 0 ? (summary.statusBreakdown.mastered / summary.totalWorksThisPeriod) * 100 : 0}%`,
                    }}
                  />
                </div>
                <span className="text-sm font-medium w-8 text-right text-white/80">
                  {summary.statusBreakdown.mastered}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* AI Insights */}
        <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-white/90">🤖 {t('summary.guruInsights')}</h2>
            <button
              onClick={generateAiInsight}
              disabled={loadingAi}
              className="px-3 py-1.5 bg-[#1D6B48] text-white rounded-lg text-sm font-medium hover:bg-[#236B4C] disabled:opacity-50 flex items-center gap-1"
            >
              {loadingAi ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>{t('summary.thinking')}</span>
                </>
              ) : aiInsight ? (
                <>🔄 {t('summary.regenerate')}</>
              ) : (
                <>✨ {t('summary.askGuru')}</>
              )}
            </button>
          </div>

          {aiInsight ? (
            <div className="p-4 rounded-xl border border-[rgba(52,211,153,0.15)]" style={{ background: 'rgba(52,211,153,0.06)' }}>
              <p className="text-sm text-white/80 whitespace-pre-wrap">{aiInsight}</p>
            </div>
          ) : (
            <div className="p-4 bg-white/[0.04] rounded-xl text-center text-white/40">
              <p className="text-sm">
                {t('summary.askGuruPrompt')}
              </p>
            </div>
          )}
        </div>

        {/* Recent Activity */}
        {summary.recentProgress.length > 0 && (
          <div className="bg-white/[0.06] border border-[rgba(52,211,153,0.15)] rounded-2xl p-4">
            <h2 className="font-bold text-white/90 mb-3">🕐 {t('summary.recentActivity')}</h2>
            <div className="space-y-2">
              {summary.recentProgress.map((p, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-2 bg-white/[0.04] rounded-lg"
                >
                  <div className="flex items-center gap-2">
                    <AreaBadge area={p.area} size="xs" />
                    <span className="text-sm font-medium text-white/85">{p.work_name}</span>
                  </div>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      p.status === 'mastered'
                        ? 'bg-emerald-500/15 text-emerald-200'
                        : p.status === 'practicing'
                        ? 'bg-blue-500/15 text-blue-200'
                        : 'bg-yellow-500/15 text-yellow-200'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Floating action - Export/Print */}
      <div className="fixed bottom-6 right-6">
        <Link
          href={`/montree/dashboard/print?child=${childId}`}
          className="w-14 h-14 bg-[#1D6B48] text-white rounded-full flex items-center justify-center shadow-xl hover:bg-[#236B4C] transition-all hover:scale-105"
        >
          <span className="text-2xl">🖨️</span>
        </Link>
      </div>
    </div>
  );
}
