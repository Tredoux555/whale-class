'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useI18n, type TranslationKey } from '@/lib/montree/i18n';
import MontreeLogo from '@/components/montree/MonteeLogo';
import LanguageToggle from '@/components/montree/LanguageToggle';

type ReasonType = 'developing_country' | 'small_school' | 'startup' | 'hardship' | 'other';
type TierType = 'tier_a_500' | 'tier_b_250' | 'tier_c_100' | 'custom';

export default function ReducedRateApplicationPage() {
  const { t } = useI18n();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Step 1: School Information
  const [schoolName, setSchoolName] = useState('');
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [estimatedStudents, setEstimatedStudents] = useState('');

  // Step 2: Financial Situation
  const [reason, setReason] = useState<ReasonType | ''>('');
  const [reasonDescription, setReasonDescription] = useState('');
  const [monthlyBudget, setMonthlyBudget] = useState('');
  const [requestedTier, setRequestedTier] = useState<TierType | ''>('');
  const [customAmount, setCustomAmount] = useState('');
  const [documentationUrl, setDocumentationUrl] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!schoolName.trim() || !country.trim() || !city.trim() || !contactName.trim() || !contactEmail.trim() || !estimatedStudents) {
      setError(t('reducedRate.validation.completeStep1' as TranslationKey));
      return;
    }

    if (!reason || !reasonDescription.trim() || !monthlyBudget || !requestedTier) {
      setError(t('reducedRate.validation.completeStep2' as TranslationKey));
      return;
    }

    if (requestedTier === 'custom' && !customAmount) {
      setError(t('reducedRate.validation.enterCustomAmount' as TranslationKey));
      return;
    }

    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/montree/apply/reduced-rate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          schoolName,
          country,
          city,
          contactName,
          contactEmail,
          estimatedStudents: parseInt(estimatedStudents),
          reason,
          reasonDescription,
          monthlyBudget: parseInt(monthlyBudget),
          requestedTier: requestedTier === 'custom' ? `custom_${customAmount}` : requestedTier,
          documentationUrl: documentationUrl || null,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || t('reducedRate.submissionFailed' as TranslationKey));
      }

      const data = await res.json();
      setSubmitted(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : t('reducedRate.submissionFailed' as TranslationKey));
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900 to-teal-900 px-6 pb-6 pt-20 relative overflow-hidden">
        {/* Home + language toggle */}
        <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-5 py-4">
          <Link href="/montree" className="flex items-center gap-2">
            <MontreeLogo size={28} />
            <span className="text-white font-light tracking-wide">Montree</span>
          </Link>
          <LanguageToggle />
        </div>
        {/* Background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Content */}
        <div className="relative z-10 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-3xl shadow-2xl shadow-emerald-500/30 mb-6">
              <span className="text-4xl">✓</span>
            </div>
            <h1 className="text-3xl font-light text-white mb-2">
              {t('reducedRate.submitted' as TranslationKey)}
            </h1>
            <p className="text-emerald-300/70 text-sm mb-8">
              {t('reducedRate.submittedThankYou' as TranslationKey)}
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-emerald-300 mb-4">{t('reducedRate.whatsNext' as TranslationKey)}</h2>
              <ul className="space-y-3 text-sm text-white/70">
                <li className="flex items-start gap-3">
                  <span className="text-emerald-400 font-bold">1.</span>
                  <span>{t('reducedRate.nextStep1' as TranslationKey)}</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-emerald-400 font-bold">2.</span>
                  <span>{t('reducedRate.nextStep2' as TranslationKey)}</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-emerald-400 font-bold">3.</span>
                  <span>{t('reducedRate.nextStep3' as TranslationKey)}</span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-white/10">
              <p className="text-white/50 text-xs">
                {t('reducedRate.applicationId' as TranslationKey)}: <span className="text-emerald-400 font-mono">{Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
              </p>
            </div>
          </div>

          <div className="mt-8">
            <Link
              href="/montree"
              className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:scale-[1.02] transition-all text-center block"
            >
              {t('reducedRate.returnToMontree' as TranslationKey)}
            </Link>
          </div>
        </div>

        {/* Footer */}
        <div className="absolute bottom-6 text-center">
          <p className="text-slate-500 text-xs">
            🌳 Montree • montree.xyz
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-emerald-900 to-teal-900 px-6 pb-6 pt-20 relative overflow-hidden">
      {/* Home + language toggle */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-5 py-4">
        <Link href="/montree" className="flex items-center gap-2">
          <MontreeLogo size={28} />
          <span className="text-white font-light tracking-wide">Montree</span>
        </Link>
        <LanguageToggle />
      </div>
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-md">
        {/* Logo & Progress */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-3xl shadow-2xl shadow-emerald-500/30 mb-6">
            <span className="text-4xl">🌱</span>
          </div>
          <h1 className="text-3xl font-light text-white mb-2">
            {t('reducedRate.title' as TranslationKey)}
          </h1>
          <p className="text-emerald-300/70 text-sm mb-6">
            {t('reducedRate.subtitle' as TranslationKey)}
          </p>

          {/* Info Banner */}
          <div className="bg-white/5 backdrop-blur border border-emerald-400/30 rounded-xl p-4 mb-6">
            <p className="text-white/70 text-xs">
              {t('reducedRate.pricingBanner' as TranslationKey)}
            </p>
          </div>

          {/* Progress dots */}
          <div className="flex justify-center gap-2">
            <div className={`w-3 h-3 rounded-full ${step >= 1 ? 'bg-emerald-400' : 'bg-white/20'}`} />
            <div className={`w-3 h-3 rounded-full ${step >= 2 ? 'bg-emerald-400' : 'bg-white/20'}`} />
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Step 1: School Information */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.schoolName' as TranslationKey)}</label>
                <input
                  type="text"
                  value={schoolName}
                  onChange={(e) => setSchoolName(e.target.value)}
                  placeholder={t('reducedRate.schoolNamePlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  autoFocus
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.country' as TranslationKey)}</label>
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder={t('reducedRate.countryPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.city' as TranslationKey)}</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder={t('reducedRate.cityPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.contactName' as TranslationKey)}</label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder={t('reducedRate.contactNamePlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.contactEmail' as TranslationKey)}</label>
                <input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  placeholder={t('reducedRate.contactEmailPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.estimatedStudents' as TranslationKey)}</label>
                <input
                  type="number"
                  value={estimatedStudents}
                  onChange={(e) => setEstimatedStudents(e.target.value)}
                  placeholder={t('reducedRate.estimatedStudentsPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  min="1"
                  required
                />
              </div>

              <button
                type="button"
                onClick={() => setStep(2)}
                disabled={!schoolName.trim() || !country.trim() || !city.trim() || !contactName.trim() || !contactEmail.trim() || !estimatedStudents}
                className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 mt-6"
              >
                {t('common.continue' as TranslationKey)} →
              </button>
            </div>
          )}

          {/* Step 2: Financial Situation */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.reason' as TranslationKey)}</label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value as ReasonType)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all appearance-none"
                  required
                >
                  <option value="">{t('reducedRate.selectReason' as TranslationKey)}</option>
                  <option value="developing_country">{t('reducedRate.reasonDeveloping' as TranslationKey)}</option>
                  <option value="small_school">{t('reducedRate.reasonSmallSchool' as TranslationKey)}</option>
                  <option value="startup">{t('reducedRate.reasonStartup' as TranslationKey)}</option>
                  <option value="hardship">{t('reducedRate.reasonHardship' as TranslationKey)}</option>
                  <option value="other">{t('reducedRate.reasonOther' as TranslationKey)}</option>
                </select>
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.explainSituation' as TranslationKey)}</label>
                <textarea
                  value={reasonDescription}
                  onChange={(e) => setReasonDescription(e.target.value)}
                  placeholder={t('reducedRate.explainPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all resize-none"
                  rows={4}
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.monthlyBudget' as TranslationKey)}</label>
                <input
                  type="number"
                  value={monthlyBudget}
                  onChange={(e) => setMonthlyBudget(e.target.value)}
                  placeholder={t('reducedRate.monthlyBudgetPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                  min="0"
                  required
                />
              </div>

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.requestedTier' as TranslationKey)}</label>
                <select
                  value={requestedTier}
                  onChange={(e) => setRequestedTier(e.target.value as TierType)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all appearance-none"
                  required
                >
                  <option value="">{t('reducedRate.selectTier' as TranslationKey)}</option>
                  <option value="tier_a_500">{t('reducedRate.tierA' as TranslationKey)}</option>
                  <option value="tier_b_250">{t('reducedRate.tierB' as TranslationKey)}</option>
                  <option value="tier_c_100">{t('reducedRate.tierC' as TranslationKey)}</option>
                  <option value="custom">{t('reducedRate.tierCustom' as TranslationKey)}</option>
                </select>
              </div>

              {requestedTier === 'custom' && (
                <div>
                  <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.customAmount' as TranslationKey)}</label>
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder={t('reducedRate.customAmountPlaceholder' as TranslationKey)}
                    className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                    min="0"
                  />
                </div>
              )}

              <div>
                <label className="block text-emerald-300/80 text-sm mb-2">{t('reducedRate.documentationUrl' as TranslationKey)}</label>
                <input
                  type="url"
                  value={documentationUrl}
                  onChange={(e) => setDocumentationUrl(e.target.value)}
                  placeholder={t('reducedRate.documentationUrlPlaceholder' as TranslationKey)}
                  className="w-full p-4 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-white placeholder-white/40 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-400/20 outline-none transition-all"
                />
              </div>

              {error && (
                <div className="p-3 bg-red-500/20 border border-red-500/30 rounded-xl">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-6 py-4 bg-white/10 backdrop-blur border border-white/20 text-white font-semibold rounded-xl hover:bg-white/20 transition-all"
                >
                  ← {t('common.back' as TranslationKey)}
                </button>
                <button
                  type="submit"
                  disabled={loading || !reason || !reasonDescription.trim() || !monthlyBudget || !requestedTier || (requestedTier === 'custom' && !customAmount)}
                  className="flex-1 py-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/30 hover:shadow-xl hover:scale-[1.02] transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  {loading ? t('reducedRate.submitting' as TranslationKey) : t('reducedRate.submitApplication' as TranslationKey)}
                </button>
              </div>
            </div>
          )}
        </form>

        {/* Links */}
        <div className="mt-8 text-center">
          <p className="text-white/50 text-sm">
            {t('reducedRate.questions' as TranslationKey)}{' '}
            <Link href="/montree" className="text-emerald-400 hover:text-emerald-300">
              {t('reducedRate.backToMontree' as TranslationKey)}
            </Link>
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-6 text-center">
        <p className="text-slate-500 text-xs">
          🌳 Montree • montree.xyz
        </p>
      </div>
    </div>
  );
}
