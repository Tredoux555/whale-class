'use client';

// app/montree/calendar/page.tsx
// Calendar Plan §11 + §12 — Phase 1 surface.
//
// Mobile-first month grid. Tap a day → detail panel below grid. Empty days
// render as quiet greys; days with events show the source icons (max 3) +
// "+N" overflow chip.
//
// Aggregation lens contract: this page knows NOTHING about the underlying
// data sources. It calls /api/montree/calendar and renders the CalendarEvent
// shape. New adapters land in the registry — this page gets them for free.

import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/montree/i18n';
import QuickCreateMenu from '@/components/montree/calendar/QuickCreateMenu';
// Session 129 follow-up — custom header (Montree wordmark + LanguageToggle)
// removed in favor of the shared DashboardHeader rendered by
// app/montree/calendar/layout.tsx. Same chrome as every other authenticated
// surface: school name, user pill, EN toggle, camera/mic, 3-dot More menu.
// Authenticated users no longer get bounced to the public landing on logo tap.
import {
  getEventColor,
  getDotGlow,
  getDotGlowStrong,
  dedupeDayDots,
} from '@/lib/montree/calendar/event-colors';

interface CalendarEvent {
  id: string;
  source: string;
  kind: 'point' | 'span' | 'allday' | 'attention';
  start: string;
  end: string | null;
  all_day: boolean;
  title: string;
  detail: string | null;
  status: 'planned' | 'done' | 'missed' | 'cancelled' | 'info';
  link: string | null;
  icon: string;
  accent: string;
  school_id: string;
  classroom_id: string | null;
  child_id: string | null;
  visibility: string;
}

type CalendarRole = 'teacher' | 'principal' | 'parent' | 'super_admin';

interface ApiResponse {
  events: CalendarEvent[];
  window: { from: string; to: string; tz: string };
  role: CalendarRole;
  sources: string[];
  errors?: Array<{ source: string; message: string }>;
}

const WEEKDAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function pad(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

function ymd(d: Date): string {
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

/** Returns the UTC date for the Monday of the week containing `d`. */
function mondayOf(d: Date): Date {
  const out = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dow = out.getUTCDay(); // 0=Sun..6=Sat
  const delta = dow === 0 ? -6 : 1 - dow;
  out.setUTCDate(out.getUTCDate() + delta);
  return out;
}

function addDays(d: Date, n: number): Date {
  const out = new Date(d.getTime());
  out.setUTCDate(out.getUTCDate() + n);
  return out;
}

/** Build a 6×7 (42-day) grid covering the month of `anchor`. */
function buildMonthGrid(anchor: Date): Date[] {
  const firstOfMonth = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth(), 1));
  const start = mondayOf(firstOfMonth);
  const cells: Date[] = [];
  for (let i = 0; i < 42; i++) cells.push(addDays(start, i));
  return cells;
}

function formatMonthLabel(d: Date): string {
  return d.toLocaleDateString(undefined, { year: 'numeric', month: 'long' });
}

function formatTimeShort(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  } catch {
    return '';
  }
}

export default function CalendarPage() {
  const { t } = useI18n();
  const [anchor, setAnchor] = useState<Date>(() => {
    const now = new Date();
    return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  });
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [role, setRole] = useState<CalendarRole | null>(null);
  const [schoolTz, setSchoolTz] = useState<string>('UTC');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>(() => ymd(new Date()));
  const [summary, setSummary] = useState<string | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const monthCells = useMemo(() => buildMonthGrid(anchor), [anchor]);
  const windowFrom = useMemo(() => ymd(monthCells[0]), [monthCells]);
  const windowTo = useMemo(() => ymd(monthCells[41]), [monthCells]);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/montree/calendar?from=${windowFrom}&to=${windowTo}`, {
        credentials: 'include',
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Calendar fetch failed (${res.status})`);
      }
      const data = (await res.json()) as ApiResponse;
      setEvents(data.events || []);
      if (data.role) setRole(data.role);
      if (data.window?.tz) setSchoolTz(data.window.tz);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load calendar');
      setEvents([]);
    } finally {
      setLoading(false);
    }
  }, [windowFrom, windowTo]);

  useEffect(() => {
    fetchEvents();
    // Window changed — the prior summary is stale.
    setSummary(null);
    setSummaryError(null);
  }, [fetchEvents]);

  const fetchSummary = useCallback(async () => {
    setSummaryLoading(true);
    setSummaryError(null);
    try {
      const res = await fetch(
        `/api/montree/calendar/summary?from=${windowFrom}&to=${windowTo}`,
        { credentials: 'include' },
      );
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Summary failed (${res.status})`);
      }
      const data = (await res.json()) as { summary: string };
      setSummary(data.summary || '');
    } catch (e) {
      setSummaryError(e instanceof Error ? e.message : 'Failed to load summary');
    } finally {
      setSummaryLoading(false);
    }
  }, [windowFrom, windowTo]);

  // Group events by YYYY-MM-DD (UTC) for the grid render.
  const eventsByDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const ev of events) {
      const day = ev.start.slice(0, 10);
      const list = map.get(day);
      if (list) list.push(ev);
      else map.set(day, [ev]);
    }
    return map;
  }, [events]);

  const today = useMemo(() => ymd(new Date()), []);
  const selectedEvents = eventsByDay.get(selectedDay) || [];
  const attentionEvents = useMemo(
    () => events.filter((e) => e.source === 'attention'),
    [events],
  );

  const monthLabel = formatMonthLabel(anchor);
  const inSelectedMonth = (d: Date) => d.getUTCMonth() === anchor.getUTCMonth();

  return (
    // Session 129 follow-up — the wrapper div keeps the dark forest
    // backdrop but no longer renders its own header. DashboardHeader is
    // rendered by app/montree/calendar/layout.tsx ABOVE this div, which
    // also honors env(safe-area-inset-top) itself — so the safe-area
    // paddingTop hack I shipped on the custom header is now redundant
    // (the layout's header carries that already).
    <div style={{ minHeight: '100dvh', background: '#0a1a0f', color: '#e2eee4' }}>
      <main style={{
        maxWidth: 1100,
        margin: '0 auto',
        // 48px nominal bottom padding + iOS home-indicator safe area so the
        // last day-detail card isn't tucked under the home indicator.
        padding: '20px 16px calc(48px + env(safe-area-inset-bottom))',
      }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 18,
            gap: 12,
            flexWrap: 'wrap',
          }}
        >
          <h1
            style={{
              margin: 0,
              fontFamily: 'Lora, serif',
              fontSize: 26,
              letterSpacing: -0.3,
            }}
          >
            {t('calendar.title') || 'Calendar'}
          </h1>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <button
              type="button"
              onClick={() =>
                setAnchor(
                  (a) => new Date(Date.UTC(a.getUTCFullYear(), a.getUTCMonth() - 1, 1)),
                )
              }
              style={navBtn}
            >
              ‹
            </button>
            <div
              style={{
                fontFamily: 'Lora, serif',
                fontSize: 18,
                minWidth: 170,
                textAlign: 'center',
                color: '#cfead4',
              }}
            >
              {monthLabel}
            </div>
            <button
              type="button"
              onClick={() =>
                setAnchor(
                  (a) => new Date(Date.UTC(a.getUTCFullYear(), a.getUTCMonth() + 1, 1)),
                )
              }
              style={navBtn}
            >
              ›
            </button>
            <button
              type="button"
              onClick={() => {
                const now = new Date();
                setAnchor(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)));
                setSelectedDay(ymd(now));
              }}
              style={{ ...navBtn, marginLeft: 8 }}
            >
              {t('calendar.today') || 'Today'}
            </button>
          </div>
        </div>

        {error ? (
          <div style={{ ...card, color: '#fca5a5' }}>{error}</div>
        ) : null}

        {attentionEvents.length > 0 && role && role !== 'parent' ? (
          <section
            style={{
              ...card,
              background: 'rgba(251,146,60,0.08)',
              border: '1px solid rgba(251,146,60,0.35)',
              marginBottom: 18,
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                marginBottom: 10,
              }}
            >
              <span style={{ fontSize: 16 }}>🚩</span>
              <h2
                style={{
                  margin: 0,
                  fontFamily: 'Lora, serif',
                  fontSize: 16,
                  color: '#fed7aa',
                }}
              >
                {t('calendar.attention.heading') || 'Needs attention'}
              </h2>
              <span style={{ fontSize: 12, color: '#fb923c' }}>
                {attentionEvents.length}
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {attentionEvents.slice(0, 6).map((ev) => (
                <a
                  key={ev.id}
                  href={ev.link || '#'}
                  onClick={ev.link ? undefined : (e) => e.preventDefault()}
                  onMouseEnter={() => setSelectedDay(ev.start.slice(0, 10))}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    gap: 8,
                    padding: '8px 10px',
                    borderRadius: 8,
                    background: 'rgba(255,255,255,0.03)',
                    color: '#fde7c8',
                    textDecoration: 'none',
                    fontSize: 13,
                  }}
                >
                  <span style={{ flex: 1, minWidth: 0 }}>{ev.title}</span>
                  <span style={{ fontSize: 11, color: '#fb923c' }}>
                    {ev.start.slice(0, 10)}
                  </span>
                </a>
              ))}
              {attentionEvents.length > 6 ? (
                <div style={{ fontSize: 12, color: '#fb923c', marginTop: 4 }}>
                  +{attentionEvents.length - 6} more
                </div>
              ) : null}
            </div>
          </section>
        ) : null}

        <section style={{ marginBottom: 18 }}>
          {summary ? (
            <div
              style={{
                ...card,
                background: 'rgba(15,30,18,0.78)',
                borderLeft: '3px solid #E8C96A',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  gap: 8,
                  marginBottom: 8,
                }}
              >
                <span
                  style={{
                    fontSize: 11,
                    color: '#E8C96A',
                    textTransform: 'uppercase',
                    letterSpacing: 0.5,
                  }}
                >
                  {t('calendar.summary.heading') || 'Summary'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSummary(null);
                    setSummaryError(null);
                  }}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: '#9bd5b0',
                    cursor: 'pointer',
                    fontSize: 12,
                  }}
                >
                  ✕
                </button>
              </div>
              <div
                style={{ fontSize: 14, lineHeight: 1.55, whiteSpace: 'pre-wrap', color: '#e9f6ec' }}
              >
                {summary}
              </div>
            </div>
          ) : (
            // Session 129 consolidation — the Summarise button and the new
            // "Set my availability" link sit side-by-side. Both are
            // meta-actions ABOUT the calendar (not events ON it). The
            // availability link replaces the standalone Appointments menu
            // entry (hidden in DashboardHeader) and roots availability
            // management inside the Calendar surface as the user requested.
            <div
              style={{
                display: 'flex',
                gap: 10,
                alignItems: 'center',
                flexWrap: 'wrap',
              }}
            >
              <button
                type="button"
                onClick={fetchSummary}
                disabled={summaryLoading || loading}
                style={{
                  background: 'rgba(232,201,106,0.14)',
                  border: '1px solid rgba(232,201,106,0.4)',
                  color: '#E8C96A',
                  padding: '10px 16px',
                  borderRadius: 10,
                  cursor: summaryLoading || loading ? 'wait' : 'pointer',
                  fontSize: 14,
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                }}
              >
                {summaryLoading
                  ? t('calendar.summary.loading') || 'Reading your calendar…'
                  : t('calendar.summary.cta') || 'Summarise this month'}
              </button>
              {/* Set my availability — only staff. Parents don't set
                  bookable slots; they BOOK the slots staff offer. */}
              {role && role !== 'parent' ? (
                <Link
                  href="/montree/dashboard/appointments"
                  style={{
                    background: 'rgba(52,211,153,0.10)',
                    border: '1px solid rgba(52,211,153,0.35)',
                    color: '#9bd5b0',
                    padding: '10px 16px',
                    borderRadius: 10,
                    fontSize: 14,
                    textDecoration: 'none',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 6,
                  }}
                >
                  {t('calendar.manageAvailability') || 'Set my availability'} →
                </Link>
              ) : null}
            </div>
          )}
          {summaryError ? (
            <div style={{ marginTop: 8, fontSize: 13, color: '#fca5a5' }}>{summaryError}</div>
          ) : null}
        </section>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(7, 1fr)',
            gap: 1,
            background: 'rgba(255,255,255,0.04)',
            borderRadius: 14,
            overflow: 'hidden',
            opacity: loading ? 0.65 : 1,
            transition: 'opacity 120ms',
          }}
        >
          {WEEKDAY_HEADERS.map((d) => (
            <div
              key={d}
              style={{
                padding: '8px 0',
                background: 'rgba(15,30,18,0.92)',
                textAlign: 'center',
                fontSize: 11,
                letterSpacing: 0.4,
                textTransform: 'uppercase',
                color: '#9bd5b0',
              }}
            >
              {d}
            </div>
          ))}
          {monthCells.map((cell) => {
            const key = ymd(cell);
            const cellEvents = eventsByDay.get(key) || [];
            const isToday = key === today;
            const isSelected = key === selectedDay;
            const inMonth = inSelectedMonth(cell);
            return (
              <button
                type="button"
                key={key}
                onClick={() => setSelectedDay(key)}
                style={{
                  background: isSelected
                    ? 'rgba(52,211,153,0.18)'
                    : 'rgba(10,20,12,0.92)',
                  border: 'none',
                  color: inMonth ? '#e2eee4' : '#5a766a',
                  padding: '10px 8px 12px',
                  minHeight: 78,
                  textAlign: 'left',
                  cursor: 'pointer',
                  position: 'relative',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 6,
                  outline: isToday ? '1px solid rgba(232,201,106,0.55)' : 'none',
                  outlineOffset: -1,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 4,
                  }}
                >
                  <span
                    style={{
                      fontSize: 13,
                      fontWeight: isToday ? 700 : 500,
                      color: isToday ? '#E8C96A' : undefined,
                    }}
                  >
                    {cell.getUTCDate()}
                  </span>
                  {isToday ? (
                    <span style={{ fontSize: 9, color: '#E8C96A', letterSpacing: 0.4 }}>
                      TODAY
                    </span>
                  ) : null}
                </div>
                {cellEvents.length > 0 ? (() => {
                  // Session 129 — deduped colored dots replace the emoji strip.
                  // Multiple parent-teacher appointments on one day collapse
                  // into ONE green dot; +N appears only when distinct flavors
                  // overflow. Cancelled events still influence color but the
                  // whole cell row fades via opacity below.
                  const allCancelled = cellEvents.every(e => e.status === 'cancelled');
                  const { dots, overflow } = dedupeDayDots(cellEvents, 5);
                  return (
                    <div
                      style={{
                        display: 'flex',
                        gap: 5,
                        flexWrap: 'wrap',
                        alignItems: 'center',
                        opacity: allCancelled ? 0.45 : 1,
                      }}
                      aria-label={`${cellEvents.length} event${cellEvents.length === 1 ? '' : 's'} scheduled`}
                    >
                      {dots.map(d => (
                        <span
                          key={d.color}
                          title={d.label}
                          aria-hidden="true"
                          style={{
                            width: 8,
                            height: 8,
                            borderRadius: '50%',
                            background: d.color,
                            boxShadow: getDotGlow(d.color),
                            display: 'inline-block',
                            flexShrink: 0,
                          }}
                        />
                      ))}
                      {overflow > 0 ? (
                        <span style={{ fontSize: 10, color: '#9bd5b0' }}>
                          +{overflow}
                        </span>
                      ) : null}
                    </div>
                  );
                })() : null}
              </button>
            );
          })}
        </div>

        <section style={{ marginTop: 24 }}>
          <h2
            style={{
              fontFamily: 'Lora, serif',
              fontSize: 19,
              margin: '0 0 12px',
              color: '#cfead4',
            }}
          >
            {new Date(`${selectedDay}T00:00:00Z`).toLocaleDateString(undefined, {
              weekday: 'long',
              day: 'numeric',
              month: 'long',
            })}
          </h2>
          {selectedEvents.length === 0 ? (
            <>
              <div style={{ ...card, color: '#7fa68d', fontSize: 14 }}>
                {t('calendar.emptyDay') || 'Nothing scheduled.'}
              </div>
              {role && role !== 'parent' ? (
                <QuickCreateMenu
                  selectedDay={selectedDay}
                  role={role}
                  tz={schoolTz}
                  onCreated={fetchEvents}
                />
              ) : null}
            </>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {selectedEvents.map((ev) => {
                const time = ev.all_day ? null : formatTimeShort(ev.start);
                const cancelled = ev.status === 'cancelled';
                // Session 129 — glowing colored dot replaces the emoji icon.
                // Dot color = canonical palette (event-colors.ts); the row's
                // accent border on the left also uses this color via the
                // adapter's `accent` field which we kept aligned.
                const dotColor = getEventColor(ev);
                return (
                  <a
                    key={ev.id}
                    href={ev.link || '#'}
                    onClick={ev.link ? undefined : (e) => e.preventDefault()}
                    style={{
                      ...card,
                      display: 'flex',
                      gap: 14,
                      alignItems: 'flex-start',
                      textDecoration: 'none',
                      color: 'inherit',
                      borderLeft: `3px solid ${dotColor.color}`,
                      opacity: cancelled ? 0.55 : 1,
                    }}
                  >
                    <span
                      aria-label={dotColor.label}
                      style={{
                        width: 14,
                        height: 14,
                        borderRadius: '50%',
                        background: dotColor.color,
                        boxShadow: getDotGlowStrong(dotColor.color),
                        flexShrink: 0,
                        marginTop: 4,
                        display: 'inline-block',
                      }}
                    />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div
                        style={{
                          fontSize: 15,
                          fontWeight: 600,
                          color: '#f5fff7',
                          textDecoration: cancelled ? 'line-through' : 'none',
                        }}
                      >
                        {ev.title}
                      </div>
                      {time ? (
                        <div style={{ fontSize: 12, color: '#9bd5b0', marginTop: 2 }}>
                          {time}
                          {ev.end ? ` · until ${formatTimeShort(ev.end)}` : ''}
                        </div>
                      ) : null}
                      {ev.detail ? (
                        <div
                          style={{
                            fontSize: 13,
                            color: '#bcd2c2',
                            marginTop: 4,
                            lineHeight: 1.4,
                          }}
                        >
                          {ev.detail}
                        </div>
                      ) : null}
                    </div>
                  </a>
                );
              })}
              {role && role !== 'parent' ? (
                <QuickCreateMenu
                  selectedDay={selectedDay}
                  role={role}
                  tz={schoolTz}
                  onCreated={fetchEvents}
                />
              ) : null}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

const navBtn: React.CSSProperties = {
  background: 'rgba(15,30,18,0.92)',
  color: '#cfead4',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 10,
  width: 34,
  height: 34,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
  fontSize: 16,
};

const card: React.CSSProperties = {
  background: 'rgba(15,30,18,0.6)',
  border: '1px solid rgba(255,255,255,0.06)',
  borderRadius: 12,
  padding: '14px 16px',
};
