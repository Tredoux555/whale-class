// /montree/home/setup/page.tsx
// Minimal child creation: name + age only
// After creation, redirects to Portal where Guru handles the rest
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getSession, recoverSession, setSession as persistSession, type MontreeSession } from '@/lib/montree/auth';
import { useI18n } from '@/lib/montree/i18n';
import { BIO } from '@/lib/montree/bioluminescent-theme';
import AmbientParticles from '@/components/montree/home/AmbientParticles';

const AGE_OPTIONS = [2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6];

export default function SetupPage() {
  const router = useRouter();
  const { t } = useI18n();
  const [session, setSession] = useState<MontreeSession | null>(null);
  const [name, setName] = useState('');
  const [age, setAge] = useState<number>(3.5);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // localStorage first, then httpOnly-cookie recovery (mirrors the home page).
      let sess = getSession();
      if (!sess) sess = await recoverSession();
      if (cancelled) return;
      if (!sess) {
        router.replace('/montree/login');
        return;
      }
      // A stale or principal-shaped session may carry no classroom — the one
      // thing this page needs. Enrich from auth/me before giving up, so a
      // first-time family never hits a dead "Session error" wall here.
      if (!sess.classroom?.id) {
        try {
          const meRes = await fetch('/api/montree/auth/me', { credentials: 'include' });
          if (meRes.ok) {
            const me = await meRes.json();
            if (me?.classroom?.id && me.teacher && me.school) {
              const enriched: MontreeSession = { teacher: me.teacher, school: me.school, classroom: me.classroom, loginAt: new Date().toISOString() };
              persistSession(enriched);
              sess = enriched;
            }
          }
        } catch { /* fall through — submit will surface a clear message */ }
      }
      if (!cancelled) setSession(sess);
    })();
    return () => { cancelled = true; };
  }, [router]);

  const handleSubmit = async () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      setError(t('home.setup.enterChildName'));
      return;
    }

    setSaving(true);
    setError('');

    try {
      // Validate classroom exists before API call
      const classroomId = session?.classroom?.id;
      if (!classroomId) {
        // Post-enrichment this only happens for classroom-less logins (e.g. a
        // principal session). Say what to DO, not just that something's wrong.
        setError("This login isn't connected to a home space. Please log in again with your own code.");
        setSaving(false);
        return;
      }

      // Create child using existing onboarding endpoint
      const res = await fetch('/api/montree/onboarding/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          classroomId,
          students: [{
            name: trimmedName,
            age,
            progress: {}, // No curriculum picker — Guru handles this
          }],
        }),
      });

      if (!res.ok) {
        let errorMsg = t('home.setup.failedToCreate');
        try {
          const data = await res.json();
          errorMsg = data.error || errorMsg;
        } catch { /* Non-JSON error response */ }
        throw new Error(errorMsg);
      }

      const data = await res.json();

      // Update session to mark as onboarded
      const sessionData = localStorage.getItem('montree_session');
      if (sessionData) {
        const parsed = JSON.parse(sessionData);
        parsed.onboarded = true;
        localStorage.setItem('montree_session', JSON.stringify(parsed));
      }

      // Get the created child ID.
      // 🚨 The onboarding endpoint returns { success: true, students: [...] } —
      // NOT `children`. The old `data.children` read was always undefined, so
      // every setup fell through to a last-index fallback on a NAME-ORDERED
      // list and could open a different child entirely (the "created Marina,
      // landed on YueZe" bug on a founder's class roster).
      let childId: string | null = null;
      const created = (data.students || data.children || []) as Array<{ id?: string; name?: string }>;
      if (created.length > 0 && created[created.length - 1]?.id) {
        childId = created[created.length - 1].id as string;
      }

      if (!childId) {
        // Fallback: fetch the roster and match the child WE JUST NAMED —
        // never "whoever sorts last".
        try {
          const childrenRes = await fetch(`/api/montree/children?classroom_id=${classroomId}`, { cache: 'no-store' });
          if (childrenRes.ok) {
            const childrenData = await childrenRes.json();
            const kids = (childrenData.children || []) as Array<{ id: string; name?: string }>;
            const match = kids.find((k) => (k.name || '').trim().toLowerCase() === trimmedName.toLowerCase());
            if (match) childId = match.id;
          }
        } catch { /* Fallback fetch failed — will redirect to dashboard */ }
      }

      if (childId) {
        // Clear any stale greeting cache
        localStorage.removeItem(`montree_greeting_${childId}`);
        router.push(`/montree/home/${childId}`);
      } else {
        router.push('/montree/dashboard');
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : t('home.setup.somethingWentWrong'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-6 ${BIO.bg.deep}`}>
      <AmbientParticles />

      <div className="relative z-10 w-full max-w-sm">
        {/* Icon */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#4ADE80]/10 flex items-center justify-center mb-4"
               style={{ boxShadow: BIO.glow.soft }}>
            <span className="text-3xl">🌿</span>
          </div>
          <h1 className={`text-2xl font-bold ${BIO.text.primary} mb-2`}>
            {t('home.setup.letBegin')}
          </h1>
          <p className={`text-sm ${BIO.text.secondary}`}>
            {t('home.setup.tellAboutChild')}
          </p>
        </div>

        {/* Name input */}
        <div className="mb-6">
          <label className={`block text-xs ${BIO.text.mint} mb-2 font-medium`}>
            {t('home.setup.childName')}
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => { setName(e.target.value); setError(''); }}
            placeholder={t('home.setup.namePlaceholder')}
            className={`w-full px-4 py-3.5 rounded-2xl border ${BIO.border.dim} ${BIO.bg.cardSolid} ${BIO.text.primary} text-base placeholder:text-white/25 focus:outline-none focus:border-[#4ADE80]/30 focus:ring-1 focus:ring-[#4ADE80]/10`}
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          />
        </div>

        {/* Age picker */}
        <div className="mb-8">
          <label className={`block text-xs ${BIO.text.mint} mb-3 font-medium`}>
            {t('home.setup.howOld')}
          </label>
          <div className="grid grid-cols-5 gap-2">
            {AGE_OPTIONS.map(a => (
              <button
                key={a}
                onClick={() => setAge(a)}
                className={`py-2.5 rounded-xl text-sm font-medium transition-all ${
                  age === a
                    ? `${BIO.btn.mint} scale-105`
                    : `${BIO.bg.card} border ${BIO.border.dim} ${BIO.text.secondary} hover:border-[#4ADE80]/20`
                }`}
                style={age === a ? { boxShadow: BIO.glow.soft } : undefined}
              >
                {a === 6 ? t('home.setup.ageLabel6plus') : a}
              </button>
            ))}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20">
            <p className="text-red-400 text-sm text-center">{error}</p>
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={saving || !name.trim()}
          className={`w-full py-4 rounded-2xl ${BIO.btn.mint} text-base transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2`}
          style={{ boxShadow: saving ? undefined : BIO.glow.medium }}
        >
          {saving ? (
            <>
              <div className="w-4 h-4 rounded-full border-2 border-[#0A1F1C]/30 border-t-[#0A1F1C] animate-spin" />
              {t('home.setup.creating')}
            </>
          ) : (
            <>
              {t('home.setup.meetGuide')}
              <span>→</span>
            </>
          )}
        </button>

        <p className={`text-center text-xs ${BIO.text.muted} mt-6`}>
          {t('home.setup.guideWillHelp')}
        </p>
      </div>
    </div>
  );
}
