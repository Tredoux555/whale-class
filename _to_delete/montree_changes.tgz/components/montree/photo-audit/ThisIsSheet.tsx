// components/montree/photo-audit/ThisIsSheet.tsx
//
// Full-screen bottom sheet that replaces the Fix + Accept + AcceptDraftModal
// tangle on the Photo Audit page. One card button "This is…" opens this
// sheet, the teacher answers the question ONCE via one of three paths,
// the photo leaves the queue. End.
//
// Three resolution paths — all end in `teacher_confirmed=true` server-side:
//
//   A. existing    — teacher picks a curriculum work from search / recents
//   B. new_custom  — teacher types a new name, picks an area, photo attaches
//                    to a freshly-created custom work. Sonnet enrichment
//                    runs fire-and-forget in the background.
//   C. confirm_ai  — teacher taps the "AI thinks X" chip when the draft is
//                    already correct. One tap, done.
//
// The parent (photo-audit/page.tsx) owns the server call — this component
// just collects a `Resolution` and hands it back via `onResolve`.

'use client';

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import type { CSSProperties } from 'react';
import { useClassroomWorks, ClassroomWork } from '@/lib/montree/hooks/useClassroomWorks';
import { useI18n } from '@/lib/montree/i18n';
import { getAreaLabel, AREA_KEYS } from '@/lib/montree/i18n/area-labels';
import UpgradeCard, { extractUpgradeFromResponse } from '@/components/montree/UpgradeCard';

const AREA_COLORS: Record<string, string> = {
  practical_life: '#10b981',
  sensorial: '#f59e0b',
  mathematics: '#6366f1',
  language: '#ec4899',
  cultural: '#8b5cf6',
};

// TYPE A: Locale-keyed labels
const SHEET_LABELS: Record<string, Record<string, string>> = {
  en: {
    aiThinks: 'AI thinks',
    createNewInstead: 'Create new work instead',
    addAsNew: 'Add as new work',
    changeArea: 'change area',
  },
  zh: {
    aiThinks: '人工智能认为',
    createNewInstead: '改为创建新工作',
    addAsNew: '添加为新工作',
    changeArea: '更改区域',
  },
  es: {
    aiThinks: 'IA piensa',
    createNewInstead: 'Crear nuevo trabajo',
    addAsNew: 'Agregar como nuevo trabajo',
    changeArea: 'cambiar área',
  },
};

/** Sub-categories under the "Others" tab. The category is persisted in
 *  sonnet_draft.other_category so reports / galleries can group by it. */
export type OtherCategory = 'behavioral_observation' | 'outdoor_play' | 'special_event';

/** Minimal shape of a montree_events row as returned by GET /api/montree/events.
 *  Only the fields the picker renders / sorts on. */
interface SheetEvent {
  id: string;
  name: string;
  event_date: string;
  classroom_id?: string | null;
}

export type Resolution =
  | { type: 'existing'; work_id: string; work_name: string; area_key: string }
  // new_custom optionally carries the teacher-reviewed work definition
  // (parent explanation / why it matters / materials) captured on the
  // addMode review screen. When `reviewed` is true the resolve route
  // writes these verbatim and the background enrichment translates them
  // but does NOT re-generate over the teacher's edits.
  | {
      type: 'new_custom';
      name: string;
      area_key: string;
      parent_description?: string;
      why_it_matters?: string;
      materials?: string[];
      // Full teacher-reviewed guide fields, present when the teacher used
      // the "Generate full teaching guide" step in the addMode review screen.
      description?: string;
      quick_guide?: string;
      direct_aims?: string[];
      presentation_steps?: string[];
      reviewed?: boolean;
    }
  | { type: 'confirm_ai'; work_id?: string; work_name: string; area_key: string }
  // Saved to the child's profile but NOT tagged against the Montessori
  // curriculum. work_id stays null, sonnet_draft.is_other = true acts as
  // the discriminator. Optional category narrows what kind of moment it is.
  //
  // `event_id` is the REAL link into montree_events — set only on the
  // 'special_event' category when the teacher picks a specific event. The
  // resolve route writes it to montree_media.event_id (the sole photo↔event
  // link). Omitted / null = "no specific event", which preserves the legacy
  // behaviour (category recorded, no event row touched).
  | { type: 'other'; category?: OtherCategory; note?: string; event_id?: string | null };

export interface ThisIsSheetPhoto {
  id: string;
  url: string | null;
  child_name: string;
  captured_at: string;
  // The currently-guessed work (from Haiku auto-tag OR Sonnet draft OR a
  // prior teacher action). Any/all may be null.
  current_work_id?: string | null;
  current_work_name?: string | null;
  current_area?: string | null;
  sonnet_draft?: {
    _source?: string;  // 'haiku_pass2' for haiku drafts, undefined/other for Sonnet drafts
    proposed_name?: string;
    suggested_area?: string;
    closest_existing_match?: { work_name?: string; similarity?: number } | null;
    confidence?: number;
    // Rich description fields the pipeline cached on the photo. The
    // new_custom resolve path copies these verbatim onto the freshly
    // created curriculum work, so the addMode preview shows the teacher
    // exactly what they're adding before they commit.
    visual_description?: string;
    parent_description?: string;
    why_it_matters?: string;
    key_materials?: string[];
  } | null;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onResolve: (resolution: Resolution) => Promise<void>;
  onDiscussionFlag?: (photoId: string) => void;
  photo: ThisIsSheetPhoto | null;
  // The parent (photo-audit/page.tsx) sometimes passes null when classroom
  // state hasn't yet loaded. useClassroomWorks already accepts null, but the
  // sheet itself becomes useless without a classroom — render nothing so we
  // don't show a broken modal with no curriculum to search.
  classroomId: string | null;
}

export default function ThisIsSheet({
  isOpen,
  onClose,
  onResolve,
  onDiscussionFlag,
  photo,
  classroomId,
}: Props) {
  const { locale, t } = useI18n();
  const [query, setQuery] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [addMode, setAddMode] = useState(false); // user tapped "add as new work"
  const [newWorkName, setNewWorkName] = useState('');
  const [newWorkArea, setNewWorkArea] = useState<string>('practical_life');
  // Editable work-definition fields shown in addMode so the teacher sees
  // (and corrects) exactly what the curriculum work will contain BEFORE
  // "Create and attach" locks it in. Pre-seeded from the photo's AI draft.
  const [newWorkParentDesc, setNewWorkParentDesc] = useState('');
  const [newWorkWhyItMatters, setNewWorkWhyItMatters] = useState('');
  const [newWorkMaterials, setNewWorkMaterials] = useState('');
  // Full teaching-guide fields — populated by the "Generate full teaching
  // guide" step (Sonnet, photo-informed). Shown in addMode once generated.
  const [newWorkDescription, setNewWorkDescription] = useState('');
  const [newWorkQuickGuide, setNewWorkQuickGuide] = useState('');
  const [newWorkDirectAims, setNewWorkDirectAims] = useState('');             // newline-separated
  const [newWorkPresentationSteps, setNewWorkPresentationSteps] = useState(''); // newline-separated
  const [newWorkTeacherPrompt, setNewWorkTeacherPrompt] = useState('');
  const [guideGenerated, setGuideGenerated] = useState(false);
  const [generatingGuide, setGeneratingGuide] = useState(false);
  const [guideError, setGuideError] = useState<string | null>(null);
  const [guideUpgrade, setGuideUpgrade] = useState<{ feature: string; upgradeUrl: string } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Two-tab UX (Session 117+): "Curriculum" (default, classic work picker)
  // and "Others" (Behavioral / Outdoor / Special Event sub-categories).
  // Tab is a UI control only — picking under Others fires the same `other`
  // resolution path used by the legacy Save-as-Other button, just with the
  // category populated. Defaults to 'curriculum' each open.
  const [activeTab, setActiveTab] = useState<'curriculum' | 'others'>('curriculum');

  // --- Special-event picker (Others tab) ---
  // Tapping "Special event" used to fire the resolution immediately with only
  // sonnet_draft.other_category='special_event' — the photo never got linked
  // to a montree_events row, so "save to my custom event" read as broken.
  // Now the card opens a real event picker; the chosen event id rides along
  // on the resolution and the resolve route writes montree_media.event_id.
  const [eventPickerOpen, setEventPickerOpen] = useState(false);
  const [sheetEvents, setSheetEvents] = useState<SheetEvent[]>([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [eventsError, setEventsError] = useState<string | null>(null);
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [newEventName, setNewEventName] = useState('');
  const [newEventDate, setNewEventDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [creatingEvent, setCreatingEvent] = useState(false);

  // --- Merge mode state ---
  const [mergeMode, setMergeMode] = useState(false);
  const [mergeSelected, setMergeSelected] = useState<Set<string>>(new Set());
  const [mergeStep, setMergeStep] = useState<'select' | 'confirm'>('select');
  const [mergeWinnerId, setMergeWinnerId] = useState<string | null>(null);
  const [mergeWinnerArea, setMergeWinnerArea] = useState<string>('practical_life');
  const [merging, setMerging] = useState(false);
  const [mergeResult, setMergeResult] = useState<{ success: boolean; message: string } | null>(null);
  const [mergedLoserIds, setMergedLoserIds] = useState<Set<string>>(new Set());

  // Lazy-load the classroom's full works list on first open of the sheet.
  const { works, loading: worksLoading, reload: reloadWorks } = useClassroomWorks(
    classroomId,
    isOpen
  );

  // Reload the works list each time the sheet opens for a new photo,
  // so custom works just added via "Add as new" are immediately searchable.
  const prevPhotoId = useRef<string | null>(null);
  useEffect(() => {
    if (isOpen && photo?.id && photo.id !== prevPhotoId.current) {
      prevPhotoId.current = photo?.id || null;
      reloadWorks();
    }
  }, [isOpen, photo?.id, reloadWorks]);

  // Reset on close / pre-seed on open
  //
  // 🚨 Dep array uses photo?.id (NOT photo) — the parent passes a fresh
  // object literal every render, so depending on `photo` itself caused this
  // effect to re-run on every parent re-render and wipe the teacher's typed
  // value back to the AI's pre-seed. photo?.id is stable per photo so the
  // effect runs once per photo as intended.
  useEffect(() => {
    if (!isOpen) {
      setQuery('');
      setAddMode(false);
      setNewWorkName('');
      setNewWorkArea('practical_life');
      setNewWorkParentDesc('');
      setNewWorkWhyItMatters('');
      setNewWorkMaterials('');
      setNewWorkDescription('');
      setNewWorkQuickGuide('');
      setNewWorkDirectAims('');
      setNewWorkPresentationSteps('');
      setNewWorkTeacherPrompt('');
      setGuideGenerated(false);
      setGeneratingGuide(false);
      setGuideError(null);
      setGuideUpgrade(null);
      setSubmitting(false);
      setMergeMode(false);
      setMergeSelected(new Set());
      setMergeStep('select');
      setMergeWinnerId(null);
      setMerging(false);
      setMergeResult(null);
      setMergedLoserIds(new Set());
      setActiveTab('curriculum');
      setEventPickerOpen(false);
      setShowCreateEvent(false);
      setNewEventName('');
      setCreatingEvent(false);
      setEventsError(null);
    } else {
      // Pre-seed the search bar with the AI's proposed_name (editable).
      //
      // Session 113 photo pipeline audit recommendation #10: only pre-seed
      // for Sonnet drafts (sonnet_drafted), NOT for Haiku drafts. Sonnet's
      // proposed_name is the result of deep deliberation with all context
      // — when it suggests a work name, it has thought about it. Haiku's
      // proposed_name is faster + cheaper but more guessy; pre-seeding
      // Haiku output into the search bar nudges the teacher toward
      // accidental duplicate-work creation when Haiku's guess is wrong
      // but PLAUSIBLE-sounding. Better to start with an empty search bar
      // for Haiku drafts so the teacher types the real name.
      //
      // Confidence floor (>= 0.4) preserved — below that, neither source
      // should pre-seed.
      const isSonnetDraft = photo?.sonnet_draft?._source !== 'haiku_pass2' && photo?.sonnet_draft?._source !== 'haiku_pass2_matched';
      const proposed = photo?.sonnet_draft?.proposed_name?.trim() || '';
      const confidence = photo?.sonnet_draft?.confidence ?? 0;
      if (proposed && confidence >= 0.4 && isSonnetDraft) setQuery(proposed);
      // Pre-seed the editable work-definition fields from the cached AI
      // draft so addMode opens showing the AI's best guess, ready for the
      // teacher to correct before committing.
      const d = photo?.sonnet_draft;
      setNewWorkParentDesc((d?.parent_description || d?.visual_description || '').trim());
      setNewWorkWhyItMatters((d?.why_it_matters || '').trim());
      setNewWorkMaterials(
        (d?.key_materials || [])
          .filter((m): m is string => typeof m === 'string' && m.trim().length > 0)
          .map(m => m.trim())
          .join(', ')
      );
      // Autofocus and select-all so a quick edit is one keypress away.
      // Using setTimeout to ensure DOM has rendered and focus can persist.
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, photo?.id]);

  // Pre-seed the "new work area" from Sonnet's suggested_area if available.
  // Same dep-stability fix as above — depend on the scalar suggested_area,
  // not the whole photo object.
  useEffect(() => {
    const suggested = photo?.sonnet_draft?.suggested_area;
    if (suggested && (AREA_KEYS as readonly string[]).includes(suggested)) {
      setNewWorkArea(suggested);
    }
  }, [photo?.sonnet_draft?.suggested_area]);

  // --- derive the "AI guess" shortcut row ---
  // Prefer an already-attached work (photo.current_work_*) because that is
  // ground truth. Fall back to closest_existing_match. Fall back to
  // proposed_name (new-work suggestion — but this can't be confirm_ai since
  // there's no work_id, so we skip the chip in that case).
  const aiGuess = useMemo<null | {
    work_name: string;
    work_name_chinese?: string;
    work_id?: string;
    area_key: string;
    source: 'attached' | 'match';
  }>(() => {
    if (!photo) return null;
    if (photo.current_work_id && photo.current_work_name) {
      // Try to find Chinese name from loaded works
      const resolved = works.find(w => w.id === photo.current_work_id);
      return {
        work_name: photo.current_work_name,
        work_name_chinese: resolved?.name_chinese || undefined,
        work_id: photo.current_work_id,
        area_key: photo.current_area || photo.sonnet_draft?.suggested_area || 'other',
        source: 'attached',
      };
    }
    const match = photo.sonnet_draft?.closest_existing_match;
    // Only trust the closest_existing_match shortcut when similarity is
    // high enough to avoid nudging the teacher toward a bad match (e.g.
    // "Paper Shredding and Cutting" → "Cutting" at 45% is NOT the same
    // work). Below the threshold, fall through to the editable search
    // bar pre-seeded with proposed_name so the teacher can create the
    // new work in one tap instead.
    const MATCH_CONFIDENCE_THRESHOLD = 0.75;
    const sim = typeof match?.similarity === 'number' ? match.similarity : 0;
    if (match?.work_name && sim >= MATCH_CONFIDENCE_THRESHOLD) {
      // We don't know the work_id from the draft cache alone, but we can
      // resolve it against the loaded classroom works list below.
      const resolved = works.find(
        w => w.name.trim().toLowerCase() === match.work_name!.trim().toLowerCase()
      );
      if (resolved) {
        return {
          work_name: resolved.name,
          work_name_chinese: resolved.name_chinese || undefined,
          work_id: resolved.id,
          area_key: resolved.area_key,
          source: 'match',
        };
      }
    }
    return null;
  }, [photo, works]);

  // --- derive filtered search results ---
  const results = useMemo(() => {
    // Filter out any works that were just merged away (losers)
    const available = mergedLoserIds.size > 0
      ? works.filter(w => !mergedLoserIds.has(w.id))
      : works;
    const q = query.trim().toLowerCase();
    if (!q) {
      // No query: show up to 10 works, prefer alphabetical
      return available.slice().sort((a, b) => a.name.localeCompare(b.name)).slice(0, 10);
    }
    const matches = available.filter(w => w.name.toLowerCase().includes(q));
    // Rank: startsWith first, then includes
    matches.sort((a, b) => {
      const aStarts = a.name.toLowerCase().startsWith(q) ? 0 : 1;
      const bStarts = b.name.toLowerCase().startsWith(q) ? 0 : 1;
      if (aStarts !== bStarts) return aStarts - bStarts;
      return a.name.localeCompare(b.name);
    });
    return matches.slice(0, 20);
  }, [query, works, mergedLoserIds]);

  // Did the query exactly match an existing work name?
  const exactMatch = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return false;
    return works.some(w => w.name.toLowerCase() === q);
  }, [query, works]);

  // Fuzzy duplicate guardrail: find the best near-match to the current
  // query so we can warn the teacher before they create a near-duplicate
  // custom work. Uses token overlap scoring — if most words in the query
  // already appear in an existing work name, it's likely a duplicate.
  const fuzzyNearMatch = useMemo<ClassroomWork | null>(() => {
    const q = query.trim().toLowerCase();
    if (!q || q.length < 3 || exactMatch) return null;
    const qTokens = q.split(/[\s\-_]+/).filter(t => t.length >= 2);
    if (qTokens.length === 0) return null;

    let bestWork: ClassroomWork | null = null;
    let bestScore = 0;
    for (const w of works) {
      const wLower = w.name.toLowerCase();
      // Skip exact matches (already handled by results list)
      if (wLower === q) continue;
      const wTokens = wLower.split(/[\s\-_]+/).filter(t => t.length >= 2);
      if (wTokens.length === 0) continue;
      // Count how many query tokens appear in the work name
      let hits = 0;
      for (const qt of qTokens) {
        if (wTokens.some(wt => wt.includes(qt) || qt.includes(wt))) hits++;
      }
      const score = hits / Math.max(qTokens.length, 1);
      if (score > bestScore && score >= 0.6) {
        bestScore = score;
        bestWork = w;
      }
    }
    return bestWork;
  }, [query, works, exactMatch]);

  // --- handlers ---
  // All resolve handlers close the sheet INSTANTLY and fire the server
  // call in the background. The parent (photo-audit/page.tsx) handles
  // success/error toasts via handleResolvePhoto. This makes the UI feel
  // instant for the teacher — no "Creating…" spinner.
  const fireAndClose = (resolution: Resolution) => {
    onClose();
    onResolve(resolution).catch(err => {
      console.error('[ThisIsSheet] background resolve failed:', err);
    });
  };

  const handlePickExisting = (work: ClassroomWork) => {
    if (submitting) return;
    fireAndClose({
      type: 'existing',
      work_id: work.id,
      work_name: work.name,
      area_key: work.area_key,
    });
  };

  const handleConfirmAI = () => {
    if (submitting || !aiGuess) return;
    fireAndClose({
      type: 'confirm_ai',
      work_id: aiGuess.work_id,
      work_name: aiGuess.work_name,
      area_key: aiGuess.area_key,
    });
  };

  const handleEnterAddMode = () => {
    setAddMode(true);
    setNewWorkName(query.trim());
  };

  // One-tap: create a new custom work directly from whatever is in the
  // search bar, using the sonnet_draft's suggested_area. The resolve
  // route copies the cached Sonnet draft's parent_description,
  // why_it_matters, and key_materials onto the new curriculum row, so
  // the created work carries exactly the description the teacher sees
  // on this card.
  const handleQuickCreateFromQuery = () => {
    const name = query.trim();
    if (submitting || !name) return;
    fireAndClose({
      type: 'new_custom',
      name,
      area_key: newWorkArea,
    });
  };

  const handleCreateNew = () => {
    const name = newWorkName.trim();
    if (submitting || !name) return;
    const materials = newWorkMaterials.split(',').map(m => m.trim()).filter(Boolean);
    const directAims = newWorkDirectAims.split('\n').map(s => s.trim()).filter(Boolean);
    const presentationSteps = newWorkPresentationSteps.split('\n').map(s => s.trim()).filter(Boolean);
    fireAndClose({
      type: 'new_custom',
      name,
      area_key: newWorkArea,
      // The teacher reviewed/edited these on the addMode screen — send
      // them so the work is created with exactly what they saw. `reviewed`
      // tells the resolve route to keep the teacher's text and skip the
      // background Sonnet re-write (translation still runs).
      parent_description: newWorkParentDesc.trim() || undefined,
      why_it_matters: newWorkWhyItMatters.trim() || undefined,
      materials: materials.length ? materials : undefined,
      // Full teaching-guide fields — empty unless the teacher ran the
      // "Generate full teaching guide" step. Empty → undefined → omitted.
      description: newWorkDescription.trim() || undefined,
      quick_guide: newWorkQuickGuide.trim() || undefined,
      direct_aims: directAims.length ? directAims : undefined,
      presentation_steps: presentationSteps.length ? presentationSteps : undefined,
      reviewed: true,
    });
  };

  // "Generate full teaching guide" — Sonnet writes the complete work
  // definition (teacher description, parent explanation, why it matters,
  // step-by-step teaching guide, materials, direct aims, presentation
  // steps), informed by the actual classroom photo. Fills every field in
  // the review panel; the teacher can then edit anything before Create.
  const handleGenerateGuide = async () => {
    const name = newWorkName.trim();
    if (!name || generatingGuide || submitting) return;
    setGeneratingGuide(true);
    setGuideError(null);
    setGuideUpgrade(null);
    try {
      const res = await fetch('/api/montree/guru/generate-work-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          work_name: name,
          area: newWorkArea,
          media_id: photo?.id,
          teacher_prompt: newWorkTeacherPrompt.trim() || undefined,
          locale,
        }),
      });
      if (res.status === 402) {
        const u = await extractUpgradeFromResponse(res);
        if (u) {
          setGuideUpgrade({ feature: u.feature, upgradeUrl: u.upgradeUrl });
          return;
        }
      }
      const data = await res.json().catch(() => ({}));
      const c = data?.content;
      if (res.ok && data?.success && c) {
        if (typeof c.description === 'string') setNewWorkDescription(c.description);
        if (typeof c.parent_description === 'string') setNewWorkParentDesc(c.parent_description);
        if (typeof c.why_it_matters === 'string') setNewWorkWhyItMatters(c.why_it_matters);
        if (typeof c.quick_guide === 'string') setNewWorkQuickGuide(c.quick_guide);
        if (Array.isArray(c.materials)) {
          setNewWorkMaterials(c.materials.filter((m: unknown): m is string => typeof m === 'string').join(', '));
        }
        if (Array.isArray(c.direct_aims)) {
          setNewWorkDirectAims(c.direct_aims.filter((a: unknown): a is string => typeof a === 'string').join('\n'));
        }
        if (Array.isArray(c.presentation_steps)) {
          setNewWorkPresentationSteps(c.presentation_steps.filter((s: unknown): s is string => typeof s === 'string').join('\n'));
        }
        setGuideGenerated(true);
      } else {
        setGuideError('Could not generate the guide — please try again.');
      }
    } catch {
      setGuideError('Could not generate the guide — please try again.');
    } finally {
      setGeneratingGuide(false);
    }
  };

  const handleDiscussionFlag = () => {
    if (!photo || !onDiscussionFlag) return;
    onDiscussionFlag(photo.id);
    onClose();
  };

  // Session 113: "Save as Other" — photo is worth keeping but isn't a
  // Montessori curriculum work (snack time, art moment, group activity,
  // parent pickup, etc.). No curriculum row created. No visual memory
  // write. No progress observation. The photo is just removed from the
  // audit queue with sonnet_draft.is_other=true as the discriminator.
  //
  // Session 117+: optional `category` narrows what kind of moment it is.
  // Persisted to sonnet_draft.other_category for future report grouping.
  const handleSaveAsOther = (category?: OtherCategory, eventId?: string | null) => {
    if (submitting) return;
    // event_id only makes sense (and is only ever passed) for special_event —
    // omit it entirely for the other categories so the resolve route's
    // "undefined = leave untouched" path applies, instead of explicitly
    // nulling out an event link on a behavioral_observation / outdoor_play
    // save.
    fireAndClose({
      type: 'other',
      category,
      event_id: category === 'special_event' ? eventId ?? null : undefined,
    });
  };

  // --- Special-event picker ---------------------------------------------
  // Loads the school's events lazily (only when the teacher actually opens
  // the picker). Events for THIS classroom and school-wide events
  // (classroom_id IS NULL) float to the top; everything else still shows so
  // a teacher can attach to another room's event if that's what happened.
  const loadSheetEvents = useCallback(async () => {
    setEventsLoading(true);
    setEventsError(null);
    try {
      const res = await fetch('/api/montree/events', { credentials: 'include' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.error || 'Could not load events');
      const list: SheetEvent[] = Array.isArray(data?.events) ? data.events : [];
      const rank = (e: SheetEvent) =>
        classroomId && e.classroom_id === classroomId ? 0 : !e.classroom_id ? 1 : 2;
      list.sort((a, b) => rank(a) - rank(b) || (b.event_date || '').localeCompare(a.event_date || ''));
      setSheetEvents(list);
    } catch (err) {
      setEventsError(err instanceof Error ? err.message : 'Could not load events');
    } finally {
      setEventsLoading(false);
    }
  }, [classroomId]);

  const handleOpenEventPicker = () => {
    if (submitting) return;
    setEventPickerOpen(true);
    if (sheetEvents.length === 0 && !eventsLoading) loadSheetEvents();
  };

  const handleCreateEvent = async () => {
    const name = newEventName.trim();
    if (!name || creatingEvent) return;
    setCreatingEvent(true);
    setEventsError(null);
    try {
      const res = await fetch('/api/montree/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          name,
          event_date: newEventDate,
          classroom_id: classroomId || undefined,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.event?.id) throw new Error(data?.error || 'Could not create event');
      // Straight through: creating an event from here means "this photo
      // belongs to it" — attach and close.
      handleSaveAsOther('special_event', data.event.id as string);
    } catch (err) {
      setEventsError(err instanceof Error ? err.message : 'Could not create event');
      setCreatingEvent(false);
    }
  };

  // --- Merge handlers ---
  const toggleMergeSelect = useCallback((workId: string) => {
    setMergeSelected(prev => {
      const next = new Set(prev);
      if (next.has(workId)) next.delete(workId); else next.add(workId);
      return next;
    });
  }, []);

  const mergeSelectedWorks = useMemo(() => {
    return works.filter(w => mergeSelected.has(w.id));
  }, [works, mergeSelected]);

  const enterMergeConfirm = useCallback(() => {
    if (mergeSelected.size < 2) return;
    // Default winner = first selected work (teacher can change)
    const first = mergeSelectedWorks[0];
    if (first) {
      setMergeWinnerId(first.id);
      setMergeWinnerArea(first.area_key);
    }
    setMergeStep('confirm');
  }, [mergeSelected, mergeSelectedWorks]);

  const handleMerge = useCallback(async () => {
    if (!mergeWinnerId || mergeSelected.size < 2 || merging) return;
    const loserIds = [...mergeSelected].filter(id => id !== mergeWinnerId);
    if (loserIds.length === 0) return;

    setMerging(true);
    setMergeResult(null);
    try {
      // If the winner's area needs to change, update it first
      const winner = works.find(w => w.id === mergeWinnerId);
      if (winner && mergeWinnerArea !== winner.area_key) {
        // Find the correct area_id for the target area from any work in that area
        const areaWork = works.find(w => w.area_key === mergeWinnerArea && w.area_id);
        if (areaWork) {
          const areaRes = await fetch('/api/montree/curriculum', {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              work_id: mergeWinnerId,
              area_id: areaWork.area_id,
            }),
          });
          if (!areaRes.ok) {
            setMergeResult({ success: false, message: 'Failed to update area — try again' });
            return;
          }
        }
      }

      // Now merge: POST to duplicates consolidation endpoint
      const res = await fetch('/api/montree/curriculum/duplicates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          winner_id: mergeWinnerId,
          loser_ids: loserIds,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setMergeResult({ success: false, message: data.error || 'Merge failed' });
        return;
      }
      // Immediately hide losers from search results and exit merge mode
      setMergedLoserIds(new Set(loserIds));
      setMergeMode(false);
      setMergeSelected(new Set());
      setMergeStep('select');
      setMergeWinnerId(null);
      setMerging(false);
      setMergeResult(null);
      // Pre-fill search with winner name so teacher can tap to tag the photo
      const winnerName = data.winner?.name || winner?.name || '';
      if (winnerName) setQuery(winnerName);
      // Background reload to sync works list from DB (mergedLoserIds filters until complete)
      reloadWorks();
    } catch (err) {
      console.error('[ThisIsSheet] merge failed:', err);
      setMergeResult({ success: false, message: 'Network error — try again' });
    } finally {
      setMerging(false);
    }
  }, [mergeWinnerId, mergeSelected, mergeWinnerArea, merging, works, reloadWorks]);

  const exitMergeMode = useCallback(() => {
    setMergeMode(false);
    setMergeSelected(new Set());
    setMergeStep('select');
    setMergeWinnerId(null);
    setMerging(false);
    setMergeResult(null);
  }, []);

  // Shared styling for the addMode work-definition fields.
  // fontSize 16 (not smaller) — anything below 16 makes iOS Safari
  // zoom the viewport on focus. Teachers edit these on a tablet.
  const fieldInputStyle: CSSProperties = {
    width: '100%',
    padding: '10px 12px',
    fontSize: 16,
    color: '#0f172a',
    caretColor: '#8b5cf6',
    background: '#ffffff',
    border: '1.5px solid #ddd',
    borderRadius: 10,
    outline: 'none',
    fontFamily: 'inherit',
    boxSizing: 'border-box',
  };
  const fieldTextareaStyle: CSSProperties = {
    ...fieldInputStyle,
    resize: 'vertical',
    lineHeight: 1.5,
  };
  const fieldLabelStyle: CSSProperties = {
    fontSize: 13,
    color: '#666',
    marginBottom: 6,
    fontWeight: 600,
  };

  if (!isOpen || !photo || !classroomId) return null;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1000,
        background: 'rgba(0,0,0,0.7)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: 680,
          height: 'min(720px, 90vh)',
          background: '#fff',
          borderRadius: 20,
          boxShadow: '0 12px 48px rgba(0,0,0,0.35)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '14px 16px 10px',
            borderBottom: '1px solid #eee',
          }}
        >
          <button
            onClick={onClose}
            disabled={submitting}
            style={{
              background: 'none',
              border: 'none',
              fontSize: 22,
              cursor: 'pointer',
              padding: 4,
              color: '#666',
            }}
            aria-label="Close"
          >
            ←
          </button>
          <div style={{ fontWeight: 600, fontSize: 17, color: '#222' }}>
            This is…
          </div>
          <div style={{ flex: 1 }} />
          {onDiscussionFlag && (
            <button
              onClick={handleDiscussionFlag}
              title={t('thisIsSheet.flagForDiscussion')}
              style={{
                background: 'none',
                border: '1px solid #ddd',
                borderRadius: 8,
                padding: '6px 10px',
                cursor: 'pointer',
                fontSize: 16,
                color: '#3b82f6',
              }}
            >
              💬
            </button>
          )}
          {photo.url && (
            <img
              src={photo.url}
              alt=""
              style={{
                width: 40,
                height: 40,
                borderRadius: 8,
                objectFit: 'cover',
                border: '1px solid #ddd',
              }}
            />
          )}
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 10 }}>
            {photo.child_name}
            {photo.captured_at && !isNaN(new Date(photo.captured_at).getTime()) && (
              <>
                {' · '}
                {new Date(photo.captured_at).toLocaleString([], {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </>
            )}
          </div>

          {!addMode && (
            <>
              {/* Two-tab strip — Curriculum (default) vs Others.
                  Tab above the search bar visually signals that Others
                  is a SEPARATE classification, not just another work in
                  the picker. */}
              <div
                style={{
                  display: 'flex',
                  gap: 4,
                  marginBottom: 12,
                  background: '#f3f4f6',
                  padding: 4,
                  borderRadius: 12,
                }}
              >
                <button
                  type="button"
                  onClick={() => setActiveTab('curriculum')}
                  disabled={submitting}
                  style={{
                    flex: 1,
                    padding: '8px 12px',
                    fontSize: 13,
                    fontWeight: 600,
                    background: activeTab === 'curriculum' ? '#ffffff' : 'transparent',
                    border: 'none',
                    borderRadius: 9,
                    color: activeTab === 'curriculum' ? '#0f172a' : '#6b7280',
                    cursor: submitting ? 'wait' : 'pointer',
                    boxShadow: activeTab === 'curriculum' ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
                    transition: 'all 140ms ease',
                  }}
                  aria-pressed={activeTab === 'curriculum'}
                >
                  📚 Curriculum
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('others')}
                  disabled={submitting}
                  style={{
                    flex: 1,
                    padding: '8px 12px',
                    fontSize: 13,
                    fontWeight: 600,
                    background: activeTab === 'others' ? '#ffffff' : 'transparent',
                    border: 'none',
                    borderRadius: 9,
                    color: activeTab === 'others' ? '#0f172a' : '#6b7280',
                    cursor: submitting ? 'wait' : 'pointer',
                    boxShadow: activeTab === 'others' ? '0 1px 3px rgba(0,0,0,0.10)' : 'none',
                    transition: 'all 140ms ease',
                  }}
                  aria-pressed={activeTab === 'others'}
                >
                  📌 Others
                </button>
              </div>

              {/* Others tab — three sub-category cards. Tap any → fires
                  the `other` resolution with that category populated. */}
              {activeTab === 'others' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 2 }}>
                    Saved to the child's profile. Not part of the curriculum — no work tagged.
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSaveAsOther('behavioral_observation')}
                    disabled={submitting}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 12,
                      width: '100%',
                      padding: '14px 16px',
                      background: '#fffbeb',
                      border: '1.5px solid #fcd34d',
                      borderRadius: 12,
                      cursor: submitting ? 'wait' : 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    <div style={{ fontSize: 22, lineHeight: 1 }}>👀</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: '#92400e' }}>
                        Behavioral observation
                      </div>
                      <div style={{ fontSize: 12, color: '#a16207', marginTop: 2 }}>
                        Something worth noting about how the child is behaving — not a work.
                      </div>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSaveAsOther('outdoor_play')}
                    disabled={submitting}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 12,
                      width: '100%',
                      padding: '14px 16px',
                      background: '#ecfdf5',
                      border: '1.5px solid #6ee7b7',
                      borderRadius: 12,
                      cursor: submitting ? 'wait' : 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    <div style={{ fontSize: 22, lineHeight: 1 }}>🌳</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: '#065f46' }}>
                        Outdoor play
                      </div>
                      <div style={{ fontSize: 12, color: '#047857', marginTop: 2 }}>
                        Free play, garden time, recess — captured for the parent's view.
                      </div>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={handleOpenEventPicker}
                    disabled={submitting}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: 12,
                      width: '100%',
                      padding: '14px 16px',
                      background: '#fdf4ff',
                      border: `1.5px solid ${eventPickerOpen ? '#a855f7' : '#d8b4fe'}`,
                      borderRadius: 12,
                      cursor: submitting ? 'wait' : 'pointer',
                      textAlign: 'left',
                    }}
                  >
                    <div style={{ fontSize: 22, lineHeight: 1 }}>🎉</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 700, color: '#6b21a8' }}>
                        Special event
                      </div>
                      <div style={{ fontSize: 12, color: '#7e22ce', marginTop: 2 }}>
                        Birthday, performance, field trip, holiday celebration.
                      </div>
                    </div>
                    <div style={{ fontSize: 14, color: '#a855f7' }}>{eventPickerOpen ? '▾' : '▸'}</div>
                  </button>

                  {/* Event picker — the actual montree_events link. Choosing a
                      row attaches the photo to that event (montree_media.event_id);
                      "No specific event" preserves the pre-Session-130 behaviour. */}
                  {eventPickerOpen && (
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 8,
                        padding: 12,
                        background: '#faf5ff',
                        border: '1px solid #e9d5ff',
                        borderRadius: 12,
                      }}
                    >
                      <div style={{ fontSize: 12, fontWeight: 600, color: '#6b21a8' }}>
                        Which event is this photo from?
                      </div>

                      <button
                        type="button"
                        onClick={() => handleSaveAsOther('special_event', null)}
                        disabled={submitting}
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          background: '#fff',
                          border: '1px solid #e9d5ff',
                          borderRadius: 10,
                          textAlign: 'left',
                          fontSize: 14,
                          color: '#4b5563',
                          cursor: submitting ? 'wait' : 'pointer',
                        }}
                      >
                        No specific event
                      </button>

                      {eventsLoading && (
                        <div style={{ fontSize: 12, color: '#7e22ce', padding: '6px 2px' }}>Loading events…</div>
                      )}
                      {eventsError && (
                        <div style={{ fontSize: 12, color: '#b91c1c', padding: '6px 2px' }}>{eventsError}</div>
                      )}
                      {!eventsLoading && !eventsError && sheetEvents.length === 0 && (
                        <div style={{ fontSize: 12, color: '#7e22ce', padding: '6px 2px' }}>
                          No events yet — create one below.
                        </div>
                      )}

                      {sheetEvents.map(ev => (
                        <button
                          key={ev.id}
                          type="button"
                          onClick={() => handleSaveAsOther('special_event', ev.id)}
                          disabled={submitting}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 10,
                            width: '100%',
                            padding: '10px 12px',
                            background: '#fff',
                            border: '1px solid #e9d5ff',
                            borderRadius: 10,
                            textAlign: 'left',
                            cursor: submitting ? 'wait' : 'pointer',
                          }}
                        >
                          <span style={{ fontSize: 16 }}>🎉</span>
                          <span style={{ flex: 1, minWidth: 0 }}>
                            <span style={{ display: 'block', fontSize: 14, fontWeight: 600, color: '#111827' }}>
                              {ev.name}
                            </span>
                            <span style={{ display: 'block', fontSize: 11, color: '#6b7280' }}>
                              {ev.event_date}{!ev.classroom_id ? ' · school-wide' : ''}
                            </span>
                          </span>
                        </button>
                      ))}

                      {showCreateEvent ? (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 2 }}>
                          <input
                            type="text"
                            value={newEventName}
                            onChange={e => setNewEventName(e.target.value)}
                            placeholder="Event name (e.g. Art Camp)"
                            style={{
                              width: '100%', padding: '9px 11px', fontSize: 14,
                              border: '1px solid #d8b4fe', borderRadius: 10, outline: 'none',
                            }}
                          />
                          <input
                            type="date"
                            value={newEventDate}
                            onChange={e => setNewEventDate(e.target.value)}
                            style={{
                              width: '100%', padding: '9px 11px', fontSize: 14,
                              border: '1px solid #d8b4fe', borderRadius: 10, outline: 'none',
                            }}
                          />
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button
                              type="button"
                              onClick={() => setShowCreateEvent(false)}
                              style={{
                                flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 14,
                                background: '#f3f4f6', border: '1px solid #e5e7eb', color: '#6b7280', cursor: 'pointer',
                              }}
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={handleCreateEvent}
                              disabled={!newEventName.trim() || creatingEvent}
                              style={{
                                flex: 1, padding: '9px 0', borderRadius: 10, fontSize: 14, fontWeight: 600,
                                background: '#a855f7', border: '1px solid #a855f7', color: '#fff',
                                opacity: !newEventName.trim() || creatingEvent ? 0.5 : 1,
                                cursor: creatingEvent ? 'wait' : 'pointer',
                              }}
                            >
                              {creatingEvent ? 'Saving…' : 'Create + attach'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setShowCreateEvent(true)}
                          style={{
                            width: '100%', padding: '9px 0', borderRadius: 10, fontSize: 13, fontWeight: 600,
                            background: '#f5f3ff', border: '1px dashed #c4b5fd', color: '#6b21a8', cursor: 'pointer',
                          }}
                        >
                          + New event
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Curriculum tab — the classic work picker (AI guess + search + new). */}
              {activeTab === 'curriculum' && (
                <>
              {/* AI guess shortcut row */}
              {aiGuess && (
                <button
                  onClick={handleConfirmAI}
                  disabled={submitting}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    width: '100%',
                    padding: '12px 14px',
                    marginBottom: 12,
                    background: '#eef2ff',
                    border: '1.5px solid #6366f1',
                    borderRadius: 12,
                    cursor: submitting ? 'wait' : 'pointer',
                    textAlign: 'left',
                  }}
                >
                  <div style={{ fontSize: 22 }}>🤖</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: '#6366f1', fontWeight: 600 }}>
                      {SHEET_LABELS[locale]?.aiThinks || SHEET_LABELS.en.aiThinks}
                    </div>
                    <div style={{ fontSize: 16, fontWeight: 600, color: '#222' }}>
                      {locale === 'zh' && aiGuess.work_name_chinese ? aiGuess.work_name_chinese : aiGuess.work_name}
                    </div>
                  </div>
                  <div
                    style={{
                      background: '#6366f1',
                      color: '#fff',
                      padding: '6px 12px',
                      borderRadius: 8,
                      fontSize: 13,
                      fontWeight: 600,
                    }}
                  >
                    ✓ Yes
                  </div>
                </button>
              )}

              {/* Search bar + New work button side by side */}
              <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                <div style={{ position: 'relative', flex: 1 }}>
                  <input
                    ref={inputRef}
                    type="text"
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    onKeyDown={e => {
                      // Allow Escape to close the modal
                      if (e.key === 'Escape') {
                        e.preventDefault();
                        onClose();
                      }
                    }}
                    placeholder="Search works…"
                    disabled={submitting}
                    autoFocus
                    spellCheck={false}
                    autoComplete="off"
                    style={{
                      width: '100%',
                      padding: '12px 14px 12px 38px',
                      fontSize: 16,
                      // Explicit color so typed text is unambiguously dark against
                      // the off-white background — without this, browser defaults
                      // can render value text in a faded grey that looks like
                      // placeholder, leading teachers to think the input is broken.
                      color: '#0f172a',
                      caretColor: '#8b5cf6',
                      border: '1.5px solid #c4b5fd',
                      borderRadius: 12,
                      outline: 'none',
                      background: '#ffffff',
                      boxShadow: '0 0 0 3px rgba(139,92,246,0.12)',
                    }}
                  />
                  <div
                    style={{
                      position: 'absolute',
                      left: 12,
                      top: '50%',
                      transform: 'translateY(-50%)',
                      fontSize: 16,
                      color: '#888',
                      pointerEvents: 'none',
                    }}
                  >
                    🔍
                  </div>
                </div>
                <button
                  onClick={() => {
                    setAddMode(true);
                    setNewWorkName(query.trim() || photo?.sonnet_draft?.proposed_name?.trim() || '');
                  }}
                  disabled={submitting}
                  style={{
                    padding: '0 16px',
                    background: '#f5f3ff',
                    border: '1.5px solid #8b5cf6',
                    borderRadius: 12,
                    cursor: 'pointer',
                    color: '#8b5cf6',
                    fontWeight: 700,
                    fontSize: 14,
                    whiteSpace: 'nowrap',
                    flexShrink: 0,
                  }}
                >
                  ＋ New
                </button>
              </div>

              {/* Results list */}
              {worksLoading && (
                <div style={{ textAlign: 'center', padding: 20, color: '#888' }}>
                  Loading curriculum…
                </div>
              )}

              {!worksLoading && results.length === 0 && query.trim() && (
                <div
                  style={{
                    padding: 14,
                    background: '#fef3c7',
                    borderRadius: 10,
                    fontSize: 14,
                    color: '#92400e',
                    marginBottom: 10,
                  }}
                >
                  <div style={{ fontWeight: 600 }}>No curriculum match for "{query.trim()}"</div>
                  {photo?.sonnet_draft?._source === 'haiku_pass2' && (
                    <div style={{ fontSize: 12, marginTop: 4, color: '#b45309' }}>
                      💡 Haiku's suggestion may be wrong — clear the search and type the correct work name to find it.
                    </div>
                  )}
                </div>
              )}

              {/* Merge toggle — show when 2+ search results */}
              {!worksLoading && results.length >= 2 && !mergeMode && (
                <button
                  onClick={() => setMergeMode(true)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '6px 12px',
                    marginBottom: 8,
                    background: 'none',
                    border: '1px solid #ddd',
                    borderRadius: 8,
                    fontSize: 12,
                    color: '#888',
                    cursor: 'pointer',
                  }}
                >
                  🔀 Merge duplicates
                </button>
              )}

              {/* Merge mode banner */}
              {mergeMode && mergeStep === 'select' && (
                <div style={{
                  padding: '10px 14px',
                  background: '#fef3c7',
                  borderRadius: 12,
                  marginBottom: 10,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#92400e' }}>
                      🔀 Select works to merge
                    </div>
                    <div style={{ fontSize: 11, color: '#b45309', marginTop: 2 }}>
                      Tap the works that are duplicates ({mergeSelected.size} selected)
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {mergeSelected.size >= 2 && (
                      <button
                        onClick={enterMergeConfirm}
                        style={{
                          padding: '6px 14px',
                          background: '#f59e0b',
                          color: '#fff',
                          border: 'none',
                          borderRadius: 8,
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: 'pointer',
                        }}
                      >
                        Next →
                      </button>
                    )}
                    <button
                      onClick={exitMergeMode}
                      style={{
                        padding: '6px 10px',
                        background: '#fff',
                        border: '1px solid #ddd',
                        borderRadius: 8,
                        fontSize: 12,
                        color: '#666',
                        cursor: 'pointer',
                      }}
                    >
                      ✕
                    </button>
                  </div>
                </div>
              )}

              {/* Merge confirm step */}
              {mergeMode && mergeStep === 'confirm' && (
                <div style={{
                  padding: 14,
                  background: '#fef3c7',
                  borderRadius: 12,
                  marginBottom: 10,
                }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#92400e', marginBottom: 10 }}>
                    🔀 Which name should we keep?
                  </div>
                  {mergeSelectedWorks.map(w => (
                    <button
                      key={w.id}
                      onClick={() => { setMergeWinnerId(w.id); setMergeWinnerArea(w.area_key); }}
                      disabled={merging}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 10,
                        width: '100%',
                        padding: '10px 12px',
                        marginBottom: 6,
                        background: mergeWinnerId === w.id ? '#dcfce7' : '#fff',
                        border: mergeWinnerId === w.id ? '2px solid #22c55e' : '1px solid #e5e7eb',
                        borderRadius: 10,
                        cursor: merging ? 'wait' : 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      {mergeWinnerId === w.id && (
                        <span style={{ fontSize: 16 }}>✅</span>
                      )}
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 600, color: '#222' }}>
                          {locale === 'zh' && w.name_chinese ? w.name_chinese : w.name}
                        </div>
                        <div style={{ fontSize: 11, color: '#888' }}>
                          {locale === 'zh' && w.area_name_zh ? w.area_name_zh : w.area_name}
                          {mergeWinnerId === w.id ? ' — keeper' : ' — will be absorbed'}
                        </div>
                      </div>
                    </button>
                  ))}

                  {/* Area correction — show when winner selected */}
                  {mergeWinnerId && (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: '#92400e', marginBottom: 6 }}>
                        Correct area for the merged work:
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                        {AREA_KEYS.map(key => {
                          const active = mergeWinnerArea === key;
                          const color = AREA_COLORS[key] || '#888';
                          return (
                            <button
                              key={key}
                              onClick={() => setMergeWinnerArea(key)}
                              disabled={merging}
                              style={{
                                padding: '5px 12px',
                                borderRadius: 999,
                                border: active ? `2px solid ${color}` : '1px solid #ddd',
                                background: active ? color + '22' : '#fff',
                                color: active ? color : '#888',
                                fontWeight: active ? 700 : 400,
                                fontSize: 12,
                                cursor: 'pointer',
                              }}
                            >
                              {getAreaLabel(key, locale)}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Merge result message */}
                  {mergeResult && (
                    <div style={{
                      marginTop: 10,
                      padding: '8px 12px',
                      borderRadius: 8,
                      background: mergeResult.success ? '#dcfce7' : '#fee2e2',
                      color: mergeResult.success ? '#166534' : '#991b1b',
                      fontSize: 13,
                    }}>
                      {mergeResult.success ? '✓ ' : '✕ '}{mergeResult.message}
                    </div>
                  )}

                  {/* Action buttons */}
                  <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                    <button
                      onClick={() => setMergeStep('select')}
                      disabled={merging}
                      style={{
                        flex: 1,
                        padding: '10px',
                        background: '#fff',
                        border: '1px solid #ddd',
                        borderRadius: 10,
                        fontSize: 13,
                        cursor: 'pointer',
                        color: '#555',
                      }}
                    >
                      ← Back
                    </button>
                    <button
                      onClick={handleMerge}
                      disabled={merging || !mergeWinnerId}
                      style={{
                        flex: 2,
                        padding: '10px',
                        background: merging || !mergeWinnerId ? '#ccc' : '#f59e0b',
                        border: 'none',
                        borderRadius: 10,
                        fontSize: 13,
                        fontWeight: 600,
                        color: '#fff',
                        cursor: merging || !mergeWinnerId ? 'not-allowed' : 'pointer',
                      }}
                    >
                      {merging ? 'Merging…' : `Merge ${mergeSelected.size} works into one`}
                    </button>
                  </div>
                </div>
              )}

              {!worksLoading && results.length > 0 && (
                <div
                  style={{
                    border: '1px solid #eee',
                    borderRadius: 12,
                    overflow: 'hidden',
                    marginBottom: 10,
                  }}
                >
                  {results.map(w => (
                    <button
                      key={w.id}
                      onClick={() => mergeMode && mergeStep === 'select'
                        ? toggleMergeSelect(w.id)
                        : handlePickExisting(w)
                      }
                      disabled={submitting || (mergeMode && mergeStep === 'confirm')}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 10,
                        width: '100%',
                        padding: '12px 14px',
                        background: mergeSelected.has(w.id) ? '#fef9c3' : '#fff',
                        border: 'none',
                        borderBottom: '1px solid #f0f0f0',
                        cursor: submitting ? 'wait' : 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      {/* Merge checkbox */}
                      {mergeMode && mergeStep === 'select' && (
                        <div style={{
                          width: 22,
                          height: 22,
                          borderRadius: 6,
                          border: mergeSelected.has(w.id) ? '2px solid #f59e0b' : '2px solid #ccc',
                          background: mergeSelected.has(w.id) ? '#fbbf24' : '#fff',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          fontSize: 13,
                          color: '#fff',
                          fontWeight: 700,
                        }}>
                          {mergeSelected.has(w.id) ? '✓' : ''}
                        </div>
                      )}
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 15, color: '#222' }}>{locale === 'zh' && w.name_chinese ? w.name_chinese : w.name}</div>
                      </div>
                      <div
                        style={{
                          fontSize: 11,
                          padding: '3px 8px',
                          borderRadius: 10,
                          background: w.area_color + '22',
                          color: w.area_color,
                          fontWeight: 600,
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {locale === 'zh' && w.area_name_zh ? w.area_name_zh : w.area_name}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Quick-create from search bar — shows when query has text
                  and doesn't exactly match an existing work. */}
              {query.trim() && !exactMatch && !worksLoading && (
                <div>
                  {/* Fuzzy duplicate guardrail */}
                  {fuzzyNearMatch && (
                    <button
                      onClick={() => handlePickExisting(fuzzyNearMatch)}
                      disabled={submitting}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 10,
                        width: '100%',
                        padding: '12px 14px',
                        marginBottom: 8,
                        background: '#fef3c7',
                        border: '1.5px solid #f59e0b',
                        borderRadius: 12,
                        cursor: submitting ? 'wait' : 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ fontSize: 18 }}>⚠️</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, color: '#92400e', fontWeight: 600 }}>
                          Did you mean this existing work?
                        </div>
                        <div style={{ fontSize: 14, color: '#222', fontWeight: 600, marginTop: 2 }}>
                          {locale === 'zh' && fuzzyNearMatch.name_chinese
                            ? fuzzyNearMatch.name_chinese
                            : fuzzyNearMatch.name}
                        </div>
                        <div style={{ fontSize: 10, color: '#92400e', marginTop: 2 }}>
                          {locale === 'zh' && fuzzyNearMatch.area_name_zh ? fuzzyNearMatch.area_name_zh : fuzzyNearMatch.area_name} — {t('thisIsSheet.tapToUseInstead')}
                        </div>
                      </div>
                    </button>
                  )}
                  {/* No exact match — offer to add as new custom work.
                      Goes through addMode (edit form) instead of instant fire-and-close,
                      so the teacher can confirm/edit the name before committing. This
                      prevents accidental creation of wrong custom works when the AI's
                      proposed name is pre-seeded but wrong. */}
                  <button
                    onClick={handleEnterAddMode}
                    disabled={submitting}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      width: '100%',
                      padding: '14px',
                      background: fuzzyNearMatch ? '#fafafa' : '#f5f3ff',
                      border: fuzzyNearMatch ? '1px dashed #ccc' : '1.5px solid #8b5cf6',
                      borderRadius: 12,
                      cursor: submitting ? 'wait' : 'pointer',
                      textAlign: 'left',
                      opacity: fuzzyNearMatch ? 0.7 : 1,
                    }}
                  >
                    <div style={{ fontSize: 22 }}>➕</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, color: fuzzyNearMatch ? '#888' : '#8b5cf6', fontWeight: 600 }}>
                        {fuzzyNearMatch ? (SHEET_LABELS[locale]?.createNewInstead || SHEET_LABELS.en.createNewInstead) : (SHEET_LABELS[locale]?.addAsNew || SHEET_LABELS.en.addAsNew)}
                      </div>
                      <div style={{ fontSize: 15, color: '#222', fontWeight: 600 }}>
                        “{query.trim()}”
                      </div>
                      <div style={{ fontSize: 11, color: '#8b5cf6', marginTop: 2 }}>
                        Tap to name and confirm
                      </div>
                    </div>
                  </button>
                </div>
              )}

              {/* Session 117+: legacy "Save as Other" pill removed — the
                  Others tab above replaces it with three explicit sub-
                  category choices (Behavioral / Outdoor / Special Event).
                  handleSaveAsOther() is preserved (called with a category
                  param from the tab UI). */}
                </>
              )}
            </>
          )}

          {addMode && (
            <div>
              <div style={{
                padding: '10px 14px',
                background: '#f5f3ff',
                borderRadius: 12,
                marginBottom: 14,
                fontSize: 13,
                color: '#6b21a8',
              }}>
                ➕ Add a new work to your classroom curriculum
              </div>
              <div style={{ fontSize: 13, color: '#666', marginBottom: 6, fontWeight: 600 }}>
                What is the work called?
              </div>
              <input
                value={newWorkName}
                onChange={e => setNewWorkName(e.target.value)}
                disabled={submitting}
                autoFocus
                placeholder="e.g. Baric Tablets, Farm Animal Matching…"
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  fontSize: 16,
                  // Explicit dark text + visible caret — without these the
                  // browser default colours can make the input look frozen.
                  color: '#0f172a',
                  caretColor: '#8b5cf6',
                  background: '#ffffff',
                  border: '1.5px solid #8b5cf6',
                  borderRadius: 12,
                  marginBottom: 14,
                  outline: 'none',
                  boxShadow: '0 0 0 3px rgba(139,92,246,0.12)',
                }}
              />

              <div style={{ fontSize: 13, color: '#666', marginBottom: 8, fontWeight: 600 }}>
                Which area?
              </div>
              <div
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: 8,
                  marginBottom: 18,
                }}
              >
                {AREA_KEYS.map(key => {
                  const active = newWorkArea === key;
                  const color = AREA_COLORS[key] || '#888';
                  return (
                    <button
                      key={key}
                      onClick={() => setNewWorkArea(key)}
                      disabled={submitting}
                      style={{
                        padding: '8px 14px',
                        borderRadius: 999,
                        border: active ? `2px solid ${color}` : '1.5px solid #ddd',
                        background: active ? color + '22' : '#fff',
                        color: active ? color : '#555',
                        fontWeight: active ? 700 : 500,
                        fontSize: 13,
                        cursor: 'pointer',
                      }}
                    >
                      {getAreaLabel(key, locale)}
                    </button>
                  );
                })}
              </div>

              {/* Generate full teaching guide — Sonnet writes the complete
                  work definition, informed by the actual classroom photo.
                  Optional notes let the teacher steer the generation. */}
              <div style={{ marginBottom: 16 }}>
                <div style={fieldLabelStyle}>
                  Notes for the AI <span style={{ fontWeight: 400, color: '#9ca3af' }}>(optional)</span>
                </div>
                <textarea
                  value={newWorkTeacherPrompt}
                  onChange={e => setNewWorkTeacherPrompt(e.target.value)}
                  disabled={submitting || generatingGuide}
                  rows={2}
                  placeholder="Anything specific about how this work is used in your classroom…"
                  style={{ ...fieldTextareaStyle, marginBottom: 10 }}
                />
                <button
                  type="button"
                  onClick={handleGenerateGuide}
                  disabled={submitting || generatingGuide || !newWorkName.trim()}
                  style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: 12,
                    border: '1.5px solid #8b5cf6',
                    background: generatingGuide ? '#ede9fe' : 'linear-gradient(180deg, #8b5cf6, #7c3aed)',
                    color: generatingGuide ? '#7c3aed' : '#fff',
                    fontWeight: 700,
                    fontSize: 14,
                    cursor: (submitting || generatingGuide || !newWorkName.trim()) ? 'not-allowed' : 'pointer',
                    opacity: (submitting || !newWorkName.trim()) ? 0.55 : 1,
                  }}
                >
                  {generatingGuide
                    ? '✨ Writing the teaching guide…'
                    : guideGenerated
                      ? '✨ Regenerate full guide'
                      : '✨ Generate full teaching guide'}
                </button>
                {guideUpgrade && (
                  <div style={{ marginTop: 10 }}>
                    <UpgradeCard feature={guideUpgrade.feature} upgradeUrl={guideUpgrade.upgradeUrl} />
                  </div>
                )}
                {guideError && !guideUpgrade && (
                  <p style={{ fontSize: 12, color: '#dc2626', marginTop: 8, textAlign: 'center' }}>
                    {guideError}
                  </p>
                )}
              </div>

              {/* Work definition — editable. The teacher sees and corrects
                  exactly what the curriculum work will contain before
                  "Create and attach" locks it in. The 3 base fields are
                  pre-filled from the photo's AI draft; the teacher-description,
                  teaching guide, aims and steps appear once the full guide
                  has been generated. What's shown is what gets saved. */}
              <div style={{ background: '#faf5ff', border: '1px solid #e9d5ff', borderRadius: 12, padding: '14px', marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#6b21a8', marginBottom: 2 }}>
                  📖 Work definition
                </div>
                <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 14 }}>
                  {guideGenerated
                    ? 'Full teaching guide generated. Edit anything — what you see here is exactly what gets saved.'
                    : 'The AI drafted this from the photo. Edit anything, or generate the full teaching guide above. What you see here is exactly what gets saved.'}
                </div>

                {guideGenerated && (
                  <>
                    <div style={fieldLabelStyle}>Teacher description</div>
                    <textarea
                      value={newWorkDescription}
                      onChange={e => setNewWorkDescription(e.target.value)}
                      disabled={submitting || generatingGuide}
                      rows={2}
                      placeholder="A short professional description of the work for teachers…"
                      style={{ ...fieldTextareaStyle, marginBottom: 14 }}
                    />
                  </>
                )}

                <div style={fieldLabelStyle}>Parent explanation</div>
                <textarea
                  value={newWorkParentDesc}
                  onChange={e => setNewWorkParentDesc(e.target.value)}
                  disabled={submitting || generatingGuide}
                  rows={4}
                  placeholder="What the child does with this work — warm, concrete language for parents…"
                  style={{ ...fieldTextareaStyle, marginBottom: 14 }}
                />

                <div style={fieldLabelStyle}>Why it matters</div>
                <textarea
                  value={newWorkWhyItMatters}
                  onChange={e => setNewWorkWhyItMatters(e.target.value)}
                  disabled={submitting || generatingGuide}
                  rows={3}
                  placeholder="The developmental purpose — what skill or concept this builds…"
                  style={{ ...fieldTextareaStyle, marginBottom: 14 }}
                />

                {guideGenerated && (
                  <>
                    <div style={fieldLabelStyle}>Teaching guide</div>
                    <textarea
                      value={newWorkQuickGuide}
                      onChange={e => setNewWorkQuickGuide(e.target.value)}
                      disabled={submitting || generatingGuide}
                      rows={6}
                      placeholder="Step-by-step guide for presenting this work…"
                      style={{ ...fieldTextareaStyle, marginBottom: 14 }}
                    />
                  </>
                )}

                <div style={fieldLabelStyle}>Materials</div>
                <input
                  value={newWorkMaterials}
                  onChange={e => setNewWorkMaterials(e.target.value)}
                  disabled={submitting || generatingGuide}
                  placeholder="e.g. wooden tray, sandpaper letters, object box"
                  style={{ ...fieldInputStyle, marginBottom: 4 }}
                />
                <div style={{ fontSize: 11, color: '#9ca3af', margin: guideGenerated ? '0 0 14px' : 0 }}>
                  Separate each material with a comma.
                </div>

                {guideGenerated && (
                  <>
                    <div style={fieldLabelStyle}>Direct aims</div>
                    <textarea
                      value={newWorkDirectAims}
                      onChange={e => setNewWorkDirectAims(e.target.value)}
                      disabled={submitting || generatingGuide}
                      rows={3}
                      placeholder="What the child explicitly learns — one per line…"
                      style={{ ...fieldTextareaStyle, marginBottom: 4 }}
                    />
                    <div style={{ fontSize: 11, color: '#9ca3af', margin: '0 0 14px' }}>One aim per line.</div>

                    <div style={fieldLabelStyle}>Presentation steps</div>
                    <textarea
                      value={newWorkPresentationSteps}
                      onChange={e => setNewWorkPresentationSteps(e.target.value)}
                      disabled={submitting || generatingGuide}
                      rows={5}
                      placeholder="Ordered steps for showing the child — one per line…"
                      style={{ ...fieldTextareaStyle, marginBottom: 4 }}
                    />
                    <div style={{ fontSize: 11, color: '#9ca3af', margin: 0 }}>One step per line.</div>
                  </>
                )}
              </div>

              <div style={{ display: 'flex', gap: 10 }}>
                <button
                  onClick={() => setAddMode(false)}
                  disabled={submitting}
                  style={{
                    flex: 1,
                    padding: '12px',
                    background: '#fff',
                    border: '1.5px solid #ddd',
                    borderRadius: 12,
                    fontSize: 15,
                    cursor: 'pointer',
                    color: '#555',
                  }}
                >
                  ← Back to search
                </button>
                <button
                  onClick={handleCreateNew}
                  disabled={submitting || !newWorkName.trim()}
                  style={{
                    flex: 2,
                    padding: '12px',
                    background: submitting || !newWorkName.trim() ? '#ccc' : '#8b5cf6',
                    border: 'none',
                    borderRadius: 12,
                    fontSize: 15,
                    fontWeight: 600,
                    color: '#fff',
                    cursor: submitting || !newWorkName.trim() ? 'not-allowed' : 'pointer',
                  }}
                >
                  {submitting ? 'Creating…' : '✓ Create and attach'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
