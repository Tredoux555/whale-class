MONTREE - WEB PACK
==================

Everything here is ready to use. No editing needed.

1 - LOGO
  montree-logo.png ............ the logo. Use this on the website.
  montree-logo-large.png ...... same logo, big (2048px), for print or banners.
  montree-logo-no-background .. gold M only, transparent. For dark backgrounds.

2 - WEBSITE
  website-text.txt ............ the text for the site. Copy and paste as is.
  montree-section.html ........ a ready-made Montree section. Paste the code
                                anywhere on the site and it works - the logo
                                is built into the code, nothing to upload.
  montree-logo.webp ........... small fast logo file (55 KB) if you prefer
                                to place the logo yourself.

3 - SOCIAL MEDIA
  profile-picture.png ......... profile picture, all platforms.
  cover-photo.png ............. Facebook / page cover.
  story-post.png .............. WhatsApp status, FB / IG story.
  post-captions.txt ........... ready captions. Copy and paste.

product-screenshot.png ........ picture of the app, for posts or articles.

RULES (only three)
  1. Always link to:  montree.xyz   (typed exactly like that)
  2. Use the text as written - do not rewrite it.
  3. Do not change the logo colours or stretch it.

Promo video (too big for this folder, use the link):
  https://montree.xyz/montree-splash-video.mp4

Need another size or format? Ask Tredoux - usually same day.
  tredoux555@gmail.com
