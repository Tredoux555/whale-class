# Montree — Media Handoff

Hi Raheem — everything you need to feature and promote Montree is in this kit. Quick map:

## For the website

- **Logo for your site:** `01 Logos/montree-m-mark-480.webp` (55 KB, transparent, web-optimised) — best on dark or muted backgrounds. On white, use `01 Logos/montree-logo-512.png` (the M on its green field) instead.
- **Link to:** `https://montree.xyz` — plain link, typed exactly like that, no redirect wrappers.
- **Text for the site:** use the one-liner or short description in `04 Copy/Montree Approved Copy.md` as-is. The product is hard to describe secondhand — this copy has been tested, please don't rewrite it.

## For social media

- Profile pictures at every standard size, a 1500×500 banner, and a 1080×1920 story/reel template are in `02 Social Media`.
- Captions, key messages by audience (teachers / parents / principals), founder bio, and hashtags are all in `04 Copy`.

## Product visuals

- `05 Product Media/montree-product-screenshot.png` — product screenshot for posts and articles.
- `05 Product Media/montree-link-preview-og.png` — the link-preview card (this is what appears automatically when you share montree.xyz, so usually you just paste the link).
- **Promo video:** hosted at `https://montree.xyz/montree-splash-video.mp4` (Chinese version: `montree-splash-video-zh.mp4`). Ask Tredoux if you'd like the files directly.

## Rules (short version)

Don't recolour, stretch, or re-set the logo in another font; keep clear space around it; full guidelines in `03 Brand Guidelines`. The old teal "sprout" logo is retired — if you find one anywhere, please don't use it.

## Anything missing?

Any other size, format, crop, or wording — just ask, it's usually same-day:

**Tredoux Willemse** (founder) — tredoux555@gmail.com · hello@montree.xyz
